# Smart Bus Tracking - API & Android App

**Complete integration package for Green Youth Academy Smart Bus Tracking system.**

✅ Persistent login (auto-login on app restart)  
✅ Modern futuristic UI with Dark Mode support  
✅ Background GPS works even when phone screen is off  
✅ No Google Maps API key needed (uses device GPS)  
✅ Pre-configured for https://greenyouthacademy.com/  

---

## 📁 Project Structure

```
greenyouthacademy.com/
├── application/              ← Main application (existing)
├── system/                   ← CodeIgniter system (existing)
├── bus_api/                  ← NEW: Smart Bus API (add this folder)
│   ├── index.php             ← API entry point
│   ├── .htaccess             ← URL rewriting
│   └── application/
│       ├── config/
│       │   ├── config.php
│       │   ├── database.php  ← UPDATE: Add your DB password
│       │   ├── routes.php
│       │   └── autoload.php
│       ├── controllers/
│       │   ├── Auth.php
│       │   ├── Smartbus.php
│       │   └── Welcome.php
│       ├── models/
│       │   └── Api_auth_model.php
│       ├── libraries/
│       │   └── Enc_lib.php
│       └── core/
│           └── MY_Controller.php
│
└── android_app/              ← Android Studio project
```

---

## 🔧 Server Installation

### Step 1: Upload bus_api folder

Upload the entire `bus_api/` folder to your server at the same level as your `application/` folder:

```
/home/empetkof/greenyouthacademy.com/bus_api/
```

### Step 2: Update Database Password

Edit `bus_api/application/config/database.php` and add your database password:

```php
$db['default'] = array(
    'hostname' => 'localhost',
    'username' => 'empetkof_green',
    'password' => 'YOUR_DB_PASSWORD_HERE',  // ← Add this
    'database' => 'empetkof_green',
    // ...
);
```

### Step 3: Run SQL Migration

Execute the SQL in `bus_api/sql/api_tokens.sql` in your database:

```sql
-- Run in phpMyAdmin or MySQL CLI
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `device_info` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `staff_id` (`staff_id`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Step 4: Test API

Visit in browser or use curl:

```bash
# Test API is running
curl https://greenyouthacademy.com/bus_api/

# Test login
curl -X POST https://greenyouthacademy.com/bus_api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"coordinator@school.com","password":"password123"}'
```

---

## 📱 Android App Setup

### Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34
- Device with NFC support

### Step 1: Open Project

1. Open Android Studio
2. Select "Open an existing project"
3. Navigate to `android_app/` folder
4. Wait for Gradle sync to complete

### Step 2: Build & Run

1. Connect Android device with NFC enabled
2. Enable USB debugging on device
3. Click "Run" or press `Shift+F10`

### Features Included

- 🔐 **Persistent Login** - Staff stays logged in until they logout
- 🌙 **Dark Mode** - Automatically adapts to system theme
- 📱 **NFC Scanning** - Tap student cards to check-in
- 📍 **Background GPS** - Shares location even when app is minimized or screen is off
- 🔄 **Auto-restart GPS** - Service restarts after phone reboot
- 🎨 **Modern UI** - Material Design 3 with glassmorphism effects

---

## 🔌 API Endpoints

**Base URL:** `https://greenyouthacademy.com/bus_api/`

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/login` | Login with email/password |
| POST | `/auth/logout` | Logout (invalidate token) |
| GET | `/auth/me` | Get current staff profile |

### Smart Bus Tracking

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/smartbus/roster` | Get students for assigned bus |
| GET | `/smartbus/status` | Get trip status |
| POST | `/smartbus/checkin` | Process NFC card scan |
| POST | `/smartbus/manual_status` | Manual board/drop/missing |
| GET | `/smartbus/trip_mode` | Get current trip mode |
| POST | `/smartbus/trip_mode` | Set pickup or drop mode |
| POST | `/smartbus/location` | Update GPS location |
| GET | `/smartbus/location` | Get bus GPS location |

---

## 🛠️ Troubleshooting

### API Issues

| Error | Solution |
|-------|----------|
| 401 Unauthorized | Token expired - login again |
| 403 Forbidden | Staff not assigned to vehicle |
| 500 Server Error | Check database password |

### Android Issues

| Issue | Solution |
|-------|----------|
| NFC not working | Enable NFC in settings |
| Location not updating | Grant background location |
| Login fails | Check internet connection |

---

**API URL:** https://greenyouthacademy.com/bus_api/
