package com.greenyouth.smartbus.api

import com.greenyouth.smartbus.data.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // ==================== Auth ====================

    @POST("bus_api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("bus_api/auth/logout")
    suspend fun logout(): Response<ApiResponse<Any>>

    @GET("bus_api/auth/me")
    suspend fun getMe(): Response<LoginResponse>

    // ==================== Smart Bus ====================

    @GET("bus_api/smartbus/status")
    suspend fun getStatus(
        @Query("trip_date") tripDate: String? = null,
        @Query("trip_type") tripType: String? = null
    ): Response<StatusResponse>

    @POST("bus_api/smartbus/checkin")
    suspend fun checkin(@Body request: CheckinRequest): Response<CheckinResponse>

    @POST("bus_api/smartbus/manual_status")
    suspend fun manualStatus(@Body request: ManualStatusRequest): Response<ManualStatusResponse>

    @GET("bus_api/smartbus/trip_mode")
    suspend fun getTripMode(): Response<TripModeResponse>

    @POST("bus_api/smartbus/trip_mode")
    suspend fun setTripMode(@Body request: TripModeRequest): Response<TripModeResponse>

    @POST("bus_api/smartbus/location")
    suspend fun updateLocation(@Body request: LocationUpdateRequest): Response<LocationUpdateResponse>
}
