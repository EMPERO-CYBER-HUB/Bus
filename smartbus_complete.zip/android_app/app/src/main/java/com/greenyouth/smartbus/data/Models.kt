package com.greenyouth.smartbus.data

import com.google.gson.annotations.SerializedName

// ==================== Auth Models ====================

data class LoginRequest(
    val email: String,
    val password: String,
    @SerializedName("device_info") val deviceInfo: String? = null
)

data class LoginResponse(
    val status: Int,
    val message: String,
    val data: LoginData?
)

data class LoginData(
    val token: String,
    @SerializedName("expires_at") val expiresAt: String,
    val staff: Staff,
    @SerializedName("assigned_vehicle") val assignedVehicle: Vehicle?,
    @SerializedName("is_coordinator") val isCoordinator: Boolean
)

data class Staff(
    val id: Int,
    @SerializedName("employee_id") val employeeId: String?,
    val name: String?,
    val email: String?,
    @SerializedName("contact_no") val contactNo: String?,
    @SerializedName("role_id") val roleId: Int?,
    @SerializedName("role_name") val roleName: String?,
    @SerializedName("photo_url") val photoUrl: String?
)

data class Vehicle(
    val id: Int,
    @SerializedName("vehicle_no") val vehicleNo: String?,
    @SerializedName("vehicle_model") val vehicleModel: String?,
    @SerializedName("driver_name") val driverName: String?,
    @SerializedName("driver_contact") val driverContact: String?,
    @SerializedName("photo_url") val photoUrl: String?
)

// ==================== Status Models ====================

data class StatusResponse(
    val status: Int,
    val message: String?,
    val data: StatusData?
)

data class StatusData(
    @SerializedName("trip_date") val tripDate: String,
    @SerializedName("trip_type") val tripType: String,
    val counts: StatusCounts,
    val statuses: List<StudentStatus>
)

data class StatusCounts(
    val total: Int,
    @SerializedName("on_bus") val onBus: Int,
    val dropped: Int,
    val missing: Int
)

data class StudentStatus(
    @SerializedName("student_session_id") val studentSessionId: Int,
    @SerializedName("admission_no") val admissionNo: String?,
    val name: String?,
    val status: String,
    @SerializedName("boarded_at") val boardedAt: String?,
    @SerializedName("dropped_at") val droppedAt: String?,
    @SerializedName("board_location") val boardLocation: GpsLocation?,
    @SerializedName("drop_location") val dropLocation: GpsLocation?
)

data class GpsLocation(
    val lat: Double?,
    val lng: Double?
)

// ==================== Check-in Models ====================

data class CheckinRequest(
    @SerializedName("card_uid") val cardUid: String,
    val lat: Double?,
    val lng: Double?,
    val accuracy: Float?
)

data class CheckinResponse(
    val status: Int,
    val message: String,
    val data: CheckinData?
)

data class CheckinData(
    val message: String?,
    val student: CheckinStudent?,
    @SerializedName("notification_sent") val notificationSent: Boolean?
)

data class CheckinStudent(
    @SerializedName("student_session_id") val studentSessionId: Int?,
    val name: String?,
    @SerializedName("admission_no") val admissionNo: String?,
    val action: String?
)

// ==================== Manual Status Models ====================

data class ManualStatusRequest(
    @SerializedName("student_session_id") val studentSessionId: Int,
    val action: String,
    val lat: Double?,
    val lng: Double?,
    val accuracy: Float?
)

data class ManualStatusResponse(
    val status: Int,
    val message: String,
    val data: Any?
)

// ==================== Trip Mode Models ====================

data class TripModeRequest(
    val mode: String
)

data class TripModeResponse(
    val status: Int,
    val message: String?,
    val data: TripModeData?
)

data class TripModeData(
    val mode: String?,
    @SerializedName("trip_date") val tripDate: String?,
    @SerializedName("auto_detected") val autoDetected: Boolean?
)

// ==================== Location Models ====================

data class LocationUpdateRequest(
    val lat: Double,
    val lng: Double,
    val accuracy: Float?,
    val heading: Float?,
    val speed: Float?
)

data class LocationUpdateResponse(
    val status: Int,
    val message: String?,
    val data: Any?
)

// ==================== Generic API Response ====================

data class ApiResponse<T>(
    val status: Int,
    val message: String?,
    val data: T?
)
