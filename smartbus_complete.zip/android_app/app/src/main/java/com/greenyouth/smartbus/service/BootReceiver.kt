package com.greenyouth.smartbus.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.greenyouth.smartbus.util.SessionManager

/**
 * Boot Receiver - Restarts GPS service after phone reboot
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            Log.d(TAG, "Boot completed, checking if should start LocationService")

            val sessionManager = SessionManager(context)

            // Only start if user is logged in and GPS sharing is enabled
            if (sessionManager.isLoggedIn() && sessionManager.isGpsSharingEnabled()) {
                Log.d(TAG, "Starting LocationService after boot")
                LocationService.startService(context)
            } else {
                Log.d(TAG, "Not starting: logged in=${sessionManager.isLoggedIn()}, gps=${sessionManager.isGpsSharingEnabled()}")
            }
        }
    }
}
