package com.greenyouth.smartbus.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.greenyouth.smartbus.data.LoginData
import com.greenyouth.smartbus.data.Staff
import com.greenyouth.smartbus.data.Vehicle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SessionManager - Handles persistent login storage
 * Token is saved securely and persists across app restarts
 */
class SessionManager(private val context: Context) {

    companion object {
        private const val PREF_NAME = "smartbus_session"
        private const val KEY_TOKEN = "auth_token"
        private const val KEY_EXPIRES_AT = "token_expires_at"
        private const val KEY_STAFF = "staff_json"
        private const val KEY_VEHICLE = "vehicle_json"
        private const val KEY_IS_COORDINATOR = "is_coordinator"
        private const val KEY_GPS_ENABLED = "gps_sharing_enabled"
        private const val KEY_TRIP_MODE = "trip_mode"
        private const val KEY_LOGIN_TIME = "login_time"
    }

    private val gson = Gson()

    // Use regular SharedPreferences (simpler, no crypto dependency issues)
    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    // ==================== Token Management ====================

    /**
     * Save login data after successful login
     */
    suspend fun saveLoginData(loginData: LoginData) = withContext(Dispatchers.IO) {
        prefs.edit().apply {
            putString(KEY_TOKEN, loginData.token)
            putString(KEY_EXPIRES_AT, loginData.expiresAt)
            putString(KEY_STAFF, gson.toJson(loginData.staff))
            putBoolean(KEY_IS_COORDINATOR, loginData.isCoordinator)
            putLong(KEY_LOGIN_TIME, System.currentTimeMillis())
            loginData.assignedVehicle?.let {
                putString(KEY_VEHICLE, gson.toJson(it))
            }
            apply()
        }
    }

    /**
     * Get token synchronously (for interceptor)
     */
    fun getTokenSync(): String? {
        val token = prefs.getString(KEY_TOKEN, null)
        val expiresAt = prefs.getString(KEY_EXPIRES_AT, null)

        // Check if token is expired
        if (token != null && expiresAt != null) {
            try {
                val expireTime = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                    .parse(expiresAt)?.time ?: 0
                if (System.currentTimeMillis() > expireTime) {
                    // Token expired, clear session
                    clearSessionSync()
                    return null
                }
            } catch (e: Exception) {
                // If parsing fails, still return token
            }
        }

        return token
    }

    /**
     * Check if user is logged in (has valid token)
     */
    fun isLoggedIn(): Boolean {
        return getTokenSync() != null
    }

    // ==================== Staff Info ====================

    fun getStaff(): Staff? {
        val json = prefs.getString(KEY_STAFF, null)
        return json?.let {
            try {
                gson.fromJson(it, Staff::class.java)
            } catch (e: Exception) {
                null
            }
        }
    }

    // ==================== Vehicle Info ====================

    fun getVehicle(): Vehicle? {
        val json = prefs.getString(KEY_VEHICLE, null)
        return json?.let {
            try {
                gson.fromJson(it, Vehicle::class.java)
            } catch (e: Exception) {
                null
            }
        }
    }

    fun isCoordinator(): Boolean {
        return prefs.getBoolean(KEY_IS_COORDINATOR, false)
    }

    // ==================== GPS Sharing ====================

    fun setGpsSharingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_GPS_ENABLED, enabled).apply()
    }

    fun isGpsSharingEnabled(): Boolean {
        return prefs.getBoolean(KEY_GPS_ENABLED, true) // Default ON
    }

    // ==================== Trip Mode ====================

    fun setTripMode(mode: String) {
        prefs.edit().putString(KEY_TRIP_MODE, mode).apply()
    }

    fun getTripMode(): String {
        val saved = prefs.getString(KEY_TRIP_MODE, null)
        if (saved != null) return saved

        // Auto-detect based on time
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (hour < 14) "morning" else "afternoon"
    }

    // ==================== Session Management ====================

    /**
     * Clear session (logout)
     */
    suspend fun clearSession() = withContext(Dispatchers.IO) {
        clearSessionSync()
    }

    private fun clearSessionSync() {
        prefs.edit().clear().apply()
    }

    /**
     * Get staff ID for location service
     */
    fun getStaffId(): Int? {
        return getStaff()?.id
    }

    /**
     * Get vehicle ID for location service
     */
    fun getVehicleId(): Int? {
        return getVehicle()?.id
    }
}
