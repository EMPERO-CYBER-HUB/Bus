package com.greenyouth.smartbus.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.LoginRequest
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val isLoading: Boolean = false,
    val loginSuccess: Boolean = false,
    val isCoordinator: Boolean = false,
    val error: String? = null
)

class LoginViewModel(
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun login(email: String, password: String, deviceInfo: String?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            try {
                val response = ApiClient.apiService.login(
                    LoginRequest(email, password, deviceInfo)
                )

                if (response.isSuccessful && response.body()?.status == 1) {
                    val loginData = response.body()!!.data!!

                    // Save login data persistently
                    sessionManager.saveLoginData(loginData)

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            loginSuccess = true,
                            isCoordinator = loginData.isCoordinator
                        )
                    }
                } else {
                    val errorMsg = response.body()?.message ?: "Login failed. Please try again."
                    _uiState.update { it.copy(isLoading = false, error = errorMsg) }
                }
            } catch (e: Exception) {
                val errorMsg = when {
                    e.message?.contains("Unable to resolve host") == true -> "No internet connection"
                    e.message?.contains("timeout") == true -> "Connection timeout. Please try again."
                    else -> "Network error: ${e.localizedMessage}"
                }
                _uiState.update { it.copy(isLoading = false, error = errorMsg) }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            sessionManager.clearSession()
            ApiClient.clearRetrofit()
            _uiState.update { LoginUiState() }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}

class LoginViewModelFactory(
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
