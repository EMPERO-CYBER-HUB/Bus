package com.greenyouth.smartbus.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.SmartBusApp
import com.greenyouth.smartbus.databinding.ActivityMainBinding
import com.greenyouth.smartbus.service.LocationService
import com.greenyouth.smartbus.ui.login.LoginActivity
import com.greenyouth.smartbus.util.NfcHelper
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels {
        MainViewModelFactory((application as SmartBusApp).sessionManager)
    }
    private lateinit var studentAdapter: StudentAdapter
    private var isNfcEnabled = false

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocation = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        if (fineLocation) {
            checkBackgroundLocationPermission()
        } else {
            Toast.makeText(this, "Location permission required for GPS sharing", Toast.LENGTH_LONG).show()
        }
    }

    private val backgroundLocationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            startLocationService()
        } else {
            showBackgroundLocationRationale()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        checkLocationPermissions()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViews()
        setupRecyclerView()
        observeViewModel()
        checkPermissions()

        // Handle NFC intent if app opened via NFC
        if (intent != null && NfcHelper.isNfcIntent(intent)) {
            handleNfcIntent(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        NfcHelper.enableForegroundDispatch(this)
        viewModel.loadStatus()
        updateNfcStatus()
    }

    override fun onPause() {
        super.onPause()
        NfcHelper.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (NfcHelper.isNfcIntent(intent)) {
            handleNfcIntent(intent)
        }
    }

    private fun setupViews() {
        // Staff name
        val staff = (application as SmartBusApp).sessionManager.getStaff()
        binding.tvStaffName.text = "Hi, ${staff?.name ?: "Coordinator"}"

        // Vehicle info
        val vehicle = (application as SmartBusApp).sessionManager.getVehicle()
        binding.tvVehicleNo.text = vehicle?.vehicleNo ?: "No Vehicle"
        binding.tvDriverInfo.text = "Driver: ${vehicle?.driverName ?: "N/A"}"

        // Trip mode toggle
        binding.toggleTripMode.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                val mode = when (checkedId) {
                    R.id.btnPickup -> "morning"
                    R.id.btnDrop -> "afternoon"
                    else -> return@addOnButtonCheckedListener
                }
                viewModel.setTripMode(mode)
            }
        }

        // Swipe refresh
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadStatus()
        }
        binding.swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent)

        // GPS toggle
        binding.switchGps.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setGpsSharing(isChecked)
            if (isChecked) {
                startLocationService()
            } else {
                LocationService.stopService(this)
            }
        }

        // NFC scan button
        binding.fabScan.setOnClickListener {
            if (!isNfcEnabled) {
                showNfcDisabledDialog()
            } else {
                showScanReadyDialog()
            }
        }

        // Logout button
        binding.btnLogout.setOnClickListener {
            showLogoutDialog()
        }

        // Refresh button
        binding.btnRefresh.setOnClickListener {
            viewModel.loadStatus()
        }
    }

    private fun setupRecyclerView() {
        studentAdapter = StudentAdapter { student ->
            showStudentActionDialog(student)
        }

        binding.recyclerStudents.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = studentAdapter
            setHasFixedSize(true)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.uiState.collectLatest { state ->
                // Loading
                binding.swipeRefresh.isRefreshing = state.isLoading
                binding.progressBar.visibility = if (state.isLoading && !binding.swipeRefresh.isRefreshing) {
                    View.VISIBLE
                } else {
                    View.GONE
                }

                // Trip mode
                val modeButtonId = when (state.tripMode) {
                    "morning" -> R.id.btnPickup
                    "afternoon" -> R.id.btnDrop
                    else -> R.id.btnPickup
                }
                if (binding.toggleTripMode.checkedButtonId != modeButtonId) {
                    binding.toggleTripMode.check(modeButtonId)
                }

                // Counts with animation
                binding.tvTotal.text = state.counts.total.toString()
                binding.tvOnBus.text = state.counts.onBus.toString()
                binding.tvDropped.text = state.counts.dropped.toString()
                binding.tvMissing.text = state.counts.missing.toString()

                // Student list
                studentAdapter.submitList(state.students)

                // GPS toggle
                if (binding.switchGps.isChecked != state.isGpsSharingEnabled) {
                    binding.switchGps.isChecked = state.isGpsSharingEnabled
                }

                // Error
                state.error?.let { error ->
                    Toast.makeText(this@MainActivity, error, Toast.LENGTH_LONG).show()
                    viewModel.clearError()
                }

                // Checkin result
                state.lastCheckinResult?.let { result ->
                    showCheckinResultDialog(result)
                    viewModel.clearCheckinResult()
                }
            }
        }
    }

    private fun handleNfcIntent(intent: Intent) {
        Log.d(TAG, "NFC Intent: ${intent.action}")

        val cardUid = NfcHelper.getTagUidFromIntent(intent)
        if (cardUid != null) {
            Log.d(TAG, "Card UID: $cardUid")
            vibrate()
            viewModel.processNfcScan(cardUid)
        } else {
            Toast.makeText(this, "Failed to read NFC card", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCheckinResultDialog(result: CheckinResult) {
        val icon = if (result.success) "✓" else "✗"
        val title = if (result.success) "$icon Success" else "$icon Error"
        val message = if (result.success) {
            "${result.studentName}\n${result.action.replaceFirstChar { it.uppercase() }}"
        } else {
            result.message
        }

        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showStudentActionDialog(student: StudentUiModel) {
        val actions = arrayOf("✓ Mark as Boarded", "✓ Mark as Dropped", "✗ Mark as Missing")

        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle(student.name)
            .setItems(actions) { _, which ->
                val action = when (which) {
                    0 -> "board"
                    1 -> "drop"
                    2 -> "missing"
                    else -> return@setItems
                }
                viewModel.manualSetStatus(student.studentSessionId, action)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showScanReadyDialog() {
        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("📱 Ready to Scan")
            .setMessage("Hold a student's NFC card near the back of your phone.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun updateNfcStatus() {
        isNfcEnabled = NfcHelper.isNfcEnabled(this)

        if (!NfcHelper.isNfcAvailable(this)) {
            binding.tvNfcStatus.text = "NFC not available"
            binding.tvNfcStatus.setTextColor(ContextCompat.getColor(this, R.color.error))
        } else if (!isNfcEnabled) {
            binding.tvNfcStatus.text = "NFC disabled - tap to enable"
            binding.tvNfcStatus.setTextColor(ContextCompat.getColor(this, R.color.warning))
            binding.tvNfcStatus.setOnClickListener { showNfcDisabledDialog() }
        } else {
            binding.tvNfcStatus.text = "✓ NFC Ready"
            binding.tvNfcStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
        }
    }

    private fun showNfcDisabledDialog() {
        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("NFC Disabled")
            .setMessage("Please enable NFC to scan student cards")
            .setPositiveButton("Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                LocationService.stopService(this)
                viewModel.logout()
                startActivity(Intent(this, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun checkPermissions() {
        // Check notification permission first (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        checkLocationPermissions()
    }

    private fun checkLocationPermissions() {
        val fineLocation = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)

        if (fineLocation != PackageManager.PERMISSION_GRANTED) {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        } else {
            checkBackgroundLocationPermission()
        }
    }

    private fun checkBackgroundLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) {
                showBackgroundLocationRationale()
                return
            }
        }
        startLocationService()
    }

    private fun showBackgroundLocationRationale() {
        AlertDialog.Builder(this, R.style.AlertDialogTheme)
            .setTitle("Background Location Required")
            .setMessage("To share bus location with parents even when the app is in the background or phone screen is off, please allow 'All the time' location access.")
            .setPositiveButton("Allow") { _, _ ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
            }
            .setNegativeButton("Skip") { _, _ ->
                startLocationService()
            }
            .show()
    }

    private fun startLocationService() {
        if ((application as SmartBusApp).sessionManager.isGpsSharingEnabled()) {
            // Request battery optimization exemption
            requestBatteryOptimizationExemption()
            LocationService.startService(this)
        }
    }

    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Error requesting battery optimization exemption", e)
                }
            }
        }
    }

    private fun vibrate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator.vibrate(
                VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(200)
            }
        }
    }
}
