package com.greenyouth.smartbus.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.databinding.ItemStudentBinding

class StudentAdapter(
    private val onStudentClick: (StudentUiModel) -> Unit
) : ListAdapter<StudentUiModel, StudentAdapter.StudentViewHolder>(StudentDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val binding = ItemStudentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return StudentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class StudentViewHolder(
        private val binding: ItemStudentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onStudentClick(getItem(position))
                }
            }
        }

        fun bind(student: StudentUiModel) {
            binding.apply {
                tvStudentName.text = student.name
                tvAdmissionNo.text = student.admissionNo

                // Status badge
                val (statusText, statusBg, statusTextColor) = when (student.status) {
                    "on_bus" -> Triple("On Bus", R.drawable.bg_status_on_bus, R.color.white)
                    "dropped" -> Triple("Dropped", R.drawable.bg_status_dropped, R.color.white)
                    else -> Triple("Missing", R.drawable.bg_status_missing, R.color.white)
                }

                tvStatus.text = statusText
                tvStatus.setBackgroundResource(statusBg)
                tvStatus.setTextColor(ContextCompat.getColor(root.context, statusTextColor))

                // Time info
                val timeText = when {
                    student.droppedAt != null -> "Dropped: ${formatTime(student.droppedAt)}"
                    student.boardedAt != null -> "Boarded: ${formatTime(student.boardedAt)}"
                    else -> null
                }

                if (timeText != null) {
                    tvTime.text = timeText
                    tvTime.visibility = View.VISIBLE
                } else {
                    tvTime.visibility = View.GONE
                }

                // Avatar with first letter
                val initial = student.name.firstOrNull()?.uppercase() ?: "?"
                tvAvatar.text = initial
            }
        }

        private fun formatTime(datetime: String?): String {
            if (datetime.isNullOrEmpty()) return ""
            return try {
                // Format: "2024-01-15 08:30:00" -> "08:30 AM"
                val timePart = datetime.substring(11, 16)
                val hour = timePart.substring(0, 2).toInt()
                val minute = timePart.substring(3, 5)
                val amPm = if (hour < 12) "AM" else "PM"
                val hour12 = when {
                    hour == 0 -> 12
                    hour > 12 -> hour - 12
                    else -> hour
                }
                "$hour12:$minute $amPm"
            } catch (e: Exception) {
                datetime
            }
        }
    }

    class StudentDiffCallback : DiffUtil.ItemCallback<StudentUiModel>() {
        override fun areItemsTheSame(oldItem: StudentUiModel, newItem: StudentUiModel): Boolean {
            return oldItem.studentSessionId == newItem.studentSessionId
        }

        override fun areContentsTheSame(oldItem: StudentUiModel, newItem: StudentUiModel): Boolean {
            return oldItem == newItem
        }
    }
}
