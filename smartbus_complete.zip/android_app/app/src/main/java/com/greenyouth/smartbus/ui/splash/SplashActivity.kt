package com.greenyouth.smartbus.ui.splash

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.greenyouth.smartbus.SmartBusApp
import com.greenyouth.smartbus.ui.login.LoginActivity
import com.greenyouth.smartbus.ui.main.MainActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Keep splash screen visible while checking login status
        var keepSplash = true
        splashScreen.setKeepOnScreenCondition { keepSplash }

        Handler(Looper.getMainLooper()).postDelayed({
            keepSplash = false
            checkLoginAndNavigate()
        }, 500) // Small delay for smooth transition
    }

    private fun checkLoginAndNavigate() {
        val sessionManager = (application as SmartBusApp).sessionManager

        val destination = if (sessionManager.isLoggedIn() && sessionManager.isCoordinator()) {
            // User is logged in and is a coordinator - go to main
            MainActivity::class.java
        } else if (sessionManager.isLoggedIn() && !sessionManager.isCoordinator()) {
            // Logged in but not coordinator - clear and go to login
            LoginActivity::class.java
        } else {
            // Not logged in - go to login
            LoginActivity::class.java
        }

        startActivity(Intent(this, destination))
        finish()
    }
}
