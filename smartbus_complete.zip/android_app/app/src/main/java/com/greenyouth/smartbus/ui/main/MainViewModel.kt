package com.greenyouth.smartbus.ui.main

import android.location.Location
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.*
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiStatusCounts(
    val total: Int = 0,
    val onBus: Int = 0,
    val dropped: Int = 0,
    val missing: Int = 0
)

data class StudentUiModel(
    val studentSessionId: Int,
    val admissionNo: String,
    val name: String,
    val status: String,
    val boardedAt: String?,
    val droppedAt: String?
)

data class CheckinResult(
    val success: Boolean,
    val message: String,
    val studentName: String = "",
    val action: String = ""
)

data class MainUiState(
    val isLoading: Boolean = false,
    val tripMode: String = "morning",
    val counts: UiStatusCounts = UiStatusCounts(),
    val students: List<StudentUiModel> = emptyList(),
    val isGpsSharingEnabled: Boolean = true,
    val error: String? = null,
    val lastCheckinResult: CheckinResult? = null
)

class MainViewModel(
    private val sessionManager: SessionManager
) : ViewModel() {

    companion object {
        private const val TAG = "MainViewModel"
    }

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var currentLocation: Location? = null

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        val tripMode = sessionManager.getTripMode()
        val gpsSharingEnabled = sessionManager.isGpsSharingEnabled()

        _uiState.update {
            it.copy(
                tripMode = tripMode,
                isGpsSharingEnabled = gpsSharingEnabled
            )
        }

        loadStatus()
    }

    fun loadStatus() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            try {
                val tripType = _uiState.value.tripMode
                val response = ApiClient.apiService.getStatus(tripType = tripType)

                if (response.isSuccessful && response.body()?.status == 1) {
                    val data = response.body()!!.data!!

                    val students = data.statuses.map { status ->
                        StudentUiModel(
                            studentSessionId = status.studentSessionId,
                            admissionNo = status.admissionNo ?: "",
                            name = status.name ?: "Unknown",
                            status = status.status,
                            boardedAt = status.boardedAt,
                            droppedAt = status.droppedAt
                        )
                    }

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            tripMode = data.tripType,
                            counts = UiStatusCounts(
                                total = data.counts.total,
                                onBus = data.counts.onBus,
                                dropped = data.counts.dropped,
                                missing = data.counts.missing
                            ),
                            students = students
                        )
                    }
                } else {
                    val errorMsg = response.body()?.message ?: "Failed to load status"
                    _uiState.update { it.copy(isLoading = false, error = errorMsg) }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading status", e)
                val errorMsg = when {
                    e.message?.contains("Unable to resolve host") == true -> "No internet connection"
                    else -> "Network error: ${e.localizedMessage}"
                }
                _uiState.update { it.copy(isLoading = false, error = errorMsg) }
            }
        }
    }

    fun setTripMode(mode: String) {
        sessionManager.setTripMode(mode)
        _uiState.update { it.copy(tripMode = mode) }

        viewModelScope.launch {
            try {
                ApiClient.apiService.setTripMode(TripModeRequest(mode))
                loadStatus()
            } catch (e: Exception) {
                Log.e(TAG, "Error setting trip mode", e)
            }
        }
    }

    fun setGpsSharing(enabled: Boolean) {
        sessionManager.setGpsSharingEnabled(enabled)
        _uiState.update { it.copy(isGpsSharingEnabled = enabled) }
    }

    fun processNfcScan(cardUid: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            try {
                val request = CheckinRequest(
                    cardUid = cardUid,
                    lat = currentLocation?.latitude,
                    lng = currentLocation?.longitude,
                    accuracy = currentLocation?.accuracy
                )

                val response = ApiClient.apiService.checkin(request)

                if (response.isSuccessful && response.body()?.status == 1) {
                    val data = response.body()!!.data

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            lastCheckinResult = CheckinResult(
                                success = true,
                                message = data?.message ?: "Success",
                                studentName = data?.student?.name ?: "",
                                action = data?.student?.action ?: ""
                            )
                        )
                    }

                    loadStatus()
                } else {
                    val errorMsg = response.body()?.message ?: "Check-in failed"
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            lastCheckinResult = CheckinResult(success = false, message = errorMsg)
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing NFC scan", e)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        lastCheckinResult = CheckinResult(
                            success = false,
                            message = "Network error: ${e.localizedMessage}"
                        )
                    )
                }
            }
        }
    }

    fun manualSetStatus(studentSessionId: Int, action: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            try {
                val request = ManualStatusRequest(
                    studentSessionId = studentSessionId,
                    action = action,
                    lat = currentLocation?.latitude,
                    lng = currentLocation?.longitude,
                    accuracy = currentLocation?.accuracy
                )

                val response = ApiClient.apiService.manualStatus(request)

                if (response.isSuccessful && response.body()?.status == 1) {
                    loadStatus()
                } else {
                    val errorMsg = response.body()?.message ?: "Failed to update status"
                    _uiState.update { it.copy(isLoading = false, error = errorMsg) }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error setting manual status", e)
                _uiState.update {
                    it.copy(isLoading = false, error = "Network error: ${e.localizedMessage}")
                }
            }
        }
    }

    fun updateLocation(location: Location) {
        currentLocation = location
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun clearCheckinResult() {
        _uiState.update { it.copy(lastCheckinResult = null) }
    }

    fun logout() {
        viewModelScope.launch {
            try {
                ApiClient.apiService.logout()
            } catch (_: Exception) {
            }

            sessionManager.clearSession()
            ApiClient.clearRetrofit()
        }
    }
}

class MainViewModelFactory(
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
