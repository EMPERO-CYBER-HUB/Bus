package com.greenyouth.smartbus

import android.app.Application
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.util.SessionManager

class SmartBusApp : Application() {

    lateinit var sessionManager: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()

        // Initialize session manager
        sessionManager = SessionManager(this)

        // Initialize API client with session manager
        ApiClient.init(sessionManager)
    }
}
