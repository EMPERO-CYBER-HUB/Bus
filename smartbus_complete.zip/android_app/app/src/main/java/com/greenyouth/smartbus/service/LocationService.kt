package com.greenyouth.smartbus.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.LocationUpdateRequest
import com.greenyouth.smartbus.ui.main.MainActivity
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.*

/**
 * Background Location Service
 * - Runs even when phone screen is off
 * - Uses wake lock to prevent CPU sleep
 * - Sends GPS updates every 5 seconds
 */
class LocationService : Service() {

    companion object {
        private const val TAG = "LocationService"
        private const val CHANNEL_ID = "smartbus_location_channel"
        private const val NOTIFICATION_ID = 1001
        private const val LOCATION_INTERVAL = 5000L // 5 seconds
        private const val FASTEST_INTERVAL = 3000L
        private const val WAKE_LOCK_TAG = "SmartBus:LocationWakeLock"

        const val ACTION_START = "com.greenyouth.smartbus.START_LOCATION"
        const val ACTION_STOP = "com.greenyouth.smartbus.STOP_LOCATION"

        fun startService(context: Context) {
            val intent = Intent(context, LocationService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, LocationService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var sessionManager: SessionManager

    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "LocationService created")

        sessionManager = SessionManager(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        createNotificationChannel()
        setupLocationCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand: ${intent?.action}")

        when (intent?.action) {
            ACTION_START -> startLocationUpdates()
            ACTION_STOP -> {
                stopLocationUpdates()
                stopSelf()
            }
        }

        // Restart if killed
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Log.d(TAG, "LocationService destroyed")
        stopLocationUpdates()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bus Location Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shares bus location with parents"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Smart Bus Tracking Active")
            .setContentText("Sharing bus location with parents...")
            .setSmallIcon(R.drawable.ic_bus)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun setupLocationCallback() {
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    Log.d(TAG, "Location: ${location.latitude}, ${location.longitude}")
                    sendLocationToServer(location)
                }
            }
        }
    }

    private fun startLocationUpdates() {
        if (isRunning) {
            Log.d(TAG, "Already running")
            return
        }

        Log.d(TAG, "Starting location updates")

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.e(TAG, "Location permission not granted")
            stopSelf()
            return
        }

        // Check if GPS sharing is enabled
        if (!sessionManager.isGpsSharingEnabled()) {
            Log.d(TAG, "GPS sharing disabled")
            stopSelf()
            return
        }

        // Start foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, createNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, createNotification())
        }

        // Acquire wake lock to keep CPU running
        acquireWakeLock()

        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            LOCATION_INTERVAL
        ).apply {
            setMinUpdateIntervalMillis(FASTEST_INTERVAL)
            setWaitForAccurateLocation(false)
        }.build()

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
            isRunning = true
            Log.d(TAG, "Location updates started")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting location updates", e)
            stopSelf()
        }
    }

    private fun stopLocationUpdates() {
        Log.d(TAG, "Stopping location updates")
        isRunning = false

        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping location updates", e)
        }

        releaseWakeLock()
    }

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                WAKE_LOCK_TAG
            ).apply {
                setReferenceCounted(false)
            }
        }
        wakeLock?.acquire(10 * 60 * 60 * 1000L) // 10 hours max
        Log.d(TAG, "Wake lock acquired")
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
                Log.d(TAG, "Wake lock released")
            }
        }
        wakeLock = null
    }

    private fun sendLocationToServer(location: Location) {
        if (!sessionManager.isLoggedIn()) {
            Log.w(TAG, "Not logged in, skipping")
            return
        }

        if (!sessionManager.isGpsSharingEnabled()) {
            Log.d(TAG, "GPS sharing disabled")
            return
        }

        serviceScope.launch {
            try {
                val request = LocationUpdateRequest(
                    lat = location.latitude,
                    lng = location.longitude,
                    accuracy = location.accuracy,
                    heading = if (location.hasBearing()) location.bearing else null,
                    speed = if (location.hasSpeed()) location.speed else null
                )

                val response = ApiClient.apiService.updateLocation(request)

                if (response.isSuccessful) {
                    Log.d(TAG, "Location sent successfully")
                } else {
                    Log.e(TAG, "Failed to send location: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending location", e)
            }
        }
    }
}
