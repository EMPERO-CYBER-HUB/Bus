<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Content-Type: application/json');
echo json_encode([
    'status' => 0,
    'message' => 'Endpoint not found'
]);
