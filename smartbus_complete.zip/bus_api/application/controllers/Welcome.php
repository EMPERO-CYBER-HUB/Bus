<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Default Controller
 * 
 * Returns API info when accessing the root URL
 */
class Welcome extends MY_Controller
{
    public function index()
    {
        $this->_success([
            'api' => 'Smart Bus Tracking API',
            'version' => '1.0.0',
            'endpoints' => [
                'POST /auth/login' => 'Login with email/password',
                'POST /auth/logout' => 'Logout (requires token)',
                'GET /auth/me' => 'Get current staff profile (requires token)',
                'GET /smartbus/roster' => 'Get students for assigned bus',
                'GET /smartbus/status' => 'Get trip status',
                'POST /smartbus/checkin' => 'NFC card scan check-in',
                'POST /smartbus/manual_status' => 'Manual board/drop/missing',
                'GET /smartbus/trip_mode' => 'Get current trip mode',
                'POST /smartbus/trip_mode' => 'Set trip mode',
                'POST /smartbus/location' => 'Update GPS location',
                'GET /smartbus/location' => 'Get bus location',
            ],
        ], 'Smart Bus API is running');
    }
}
