<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Smart Bus Tracking API Controller
 * 
 * Endpoints:
 * - GET  /smartbus/roster          - Get students for assigned bus
 * - GET  /smartbus/status          - Get trip status
 * - POST /smartbus/checkin         - NFC card scan check-in
 * - POST /smartbus/manual_status   - Manual board/drop/missing
 * - GET  /smartbus/trip_mode       - Get current trip mode
 * - POST /smartbus/trip_mode       - Set trip mode
 * - POST /smartbus/location        - Update GPS location
 * - GET  /smartbus/location        - Get bus location
 */
class Smartbus extends MY_Controller
{
    protected $vehicle = null;

    public function __construct()
    {
        parent::__construct();
        
        // Load models from main application path
        $this->load->model('Smartbustracking_model', '', TRUE);
        $this->load->model('Studentrfid_model', '', TRUE);
    }

    /**
     * Verify coordinator has assigned vehicle
     */
    protected function _requireVehicle()
    {
        $this->vehicle = $this->Api_auth_model->getAssignedVehicle($this->staff_id);
        
        if (!$this->vehicle) {
            $this->_forbidden('No vehicle assigned to this coordinator');
            return false;
        }
        return true;
    }

    /**
     * GET /smartbus/roster
     */
    public function roster()
    {
        if (!$this->_requireGet()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $vehicle_id = (int)$this->vehicle['id'];
        $students = $this->Smartbustracking_model->getExpectedStudentsByVehicle($vehicle_id);

        // Get RFID cards
        $student_session_ids = array_column($students, 'student_session_id');
        $rfid_map = [];
        if (!empty($student_session_ids)) {
            $rfid_map = $this->Studentrfid_model->getByStudentSessionIds($student_session_ids);
        }

        $base_url = rtrim(str_replace('/bus_api/', '/', config_item('base_url')), '/');

        $roster = [];
        foreach ($students as $student) {
            $ss_id = (int)$student['student_session_id'];
            $photo_url = null;
            if (!empty($student['image'])) {
                $photo_url = $base_url . '/uploads/student_images/' . $student['image'];
            }

            $roster[] = [
                'student_session_id' => $ss_id,
                'student_id' => (int)($student['student_id'] ?? 0),
                'admission_no' => $student['admission_no'] ?? '',
                'name' => trim(($student['firstname'] ?? '') . ' ' . ($student['middlename'] ?? '') . ' ' . ($student['lastname'] ?? '')),
                'class' => $student['class'] ?? '',
                'section' => $student['section'] ?? '',
                'guardian_name' => $student['guardian_name'] ?? '',
                'guardian_phone' => $student['guardian_phone'] ?? '',
                'photo_url' => $photo_url,
                'pickup_point' => $student['pickup_point'] ?? '',
                'card_uid' => isset($rfid_map[$ss_id]) ? $rfid_map[$ss_id]['card_uid'] : null,
                'has_rfid' => isset($rfid_map[$ss_id]),
            ];
        }

        $this->_success([
            'vehicle' => [
                'id' => (int)$this->vehicle['id'],
                'vehicle_no' => $this->vehicle['vehicle_no'] ?? '',
                'driver_name' => $this->vehicle['driver_name'] ?? '',
                'driver_contact' => $this->vehicle['driver_contact'] ?? '',
            ],
            'student_count' => count($roster),
            'students' => $roster,
        ]);
    }

    /**
     * GET /smartbus/status
     */
    public function status()
    {
        if (!$this->_requireGet()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $vehicle_id = (int)$this->vehicle['id'];
        $trip_date = $this->input->get('trip_date') ?: date('Y-m-d');
        $trip_type = $this->input->get('trip_type') ?: $this->_detectTripType();

        $status_map = $this->Smartbustracking_model->getTripStatusMap($vehicle_id, $trip_date, $trip_type);
        $students = $this->Smartbustracking_model->getExpectedStudentsByVehicle($vehicle_id);

        $statuses = [];
        $counts = ['total' => 0, 'on_bus' => 0, 'dropped' => 0, 'missing' => 0];
        
        foreach ($students as $student) {
            $ss_id = (int)$student['student_session_id'];
            $checkin = isset($status_map[$ss_id]) ? $status_map[$ss_id] : null;
            
            $status = 'missing';
            $boarded_at = null;
            $dropped_at = null;
            
            if ($checkin) {
                $boarded_at = isset($checkin['boarded_at']) ? $checkin['boarded_at'] : null;
                $dropped_at = isset($checkin['dropped_at']) ? $checkin['dropped_at'] : null;
                
                if ($trip_type === 'morning') {
                    $status = $boarded_at ? 'on_bus' : 'missing';
                } else {
                    if ($dropped_at) {
                        $status = 'dropped';
                    } elseif ($boarded_at) {
                        $status = 'on_bus';
                    } else {
                        $status = 'missing';
                    }
                }
            }

            $counts['total']++;
            $counts[$status]++;

            $statuses[] = [
                'student_session_id' => $ss_id,
                'admission_no' => $student['admission_no'] ?? '',
                'name' => trim(($student['firstname'] ?? '') . ' ' . ($student['lastname'] ?? '')),
                'status' => $status,
                'boarded_at' => $boarded_at,
                'dropped_at' => $dropped_at,
            ];
        }

        $this->_success([
            'trip_date' => $trip_date,
            'trip_type' => $trip_type,
            'counts' => $counts,
            'statuses' => $statuses,
        ]);
    }

    /**
     * POST /smartbus/checkin
     */
    public function checkin()
    {
        if (!$this->_requirePost()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $json = $this->_getJsonInput();
        $card_uid = isset($json['card_uid']) ? $json['card_uid'] : $this->input->post('card_uid');
        $lat = isset($json['lat']) ? $json['lat'] : $this->input->post('lat');
        $lng = isset($json['lng']) ? $json['lng'] : $this->input->post('lng');
        $accuracy = isset($json['accuracy']) ? $json['accuracy'] : $this->input->post('accuracy');

        if (empty($card_uid)) {
            $this->_error('card_uid is required', 400);
            return;
        }

        $vehicle_id = (int)$this->vehicle['id'];
        $trip_date = date('Y-m-d');
        $trip_type = $this->_getCurrentTripMode($vehicle_id, $trip_date);

        $result = $this->Smartbustracking_model->checkInByUid(
            $vehicle_id,
            $card_uid,
            $trip_date,
            $trip_type,
            $this->staff_id,
            $lat ? (float)$lat : null,
            $lng ? (float)$lng : null,
            $accuracy ? (float)$accuracy : null
        );

        if (!$result['success']) {
            $this->_error($result['message'], 400);
            return;
        }

        $this->_success([
            'message' => $result['message'],
            'student' => [
                'student_session_id' => isset($result['student_session_id']) ? $result['student_session_id'] : null,
                'name' => isset($result['student_name']) ? $result['student_name'] : '',
                'admission_no' => isset($result['admission_no']) ? $result['admission_no'] : '',
                'action' => isset($result['action']) ? $result['action'] : '',
            ],
            'notification_sent' => isset($result['notification_sent']) ? $result['notification_sent'] : false,
        ]);
    }

    /**
     * POST /smartbus/manual_status
     */
    public function manual_status()
    {
        if (!$this->_requirePost()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $json = $this->_getJsonInput();
        $student_session_id = isset($json['student_session_id']) ? $json['student_session_id'] : $this->input->post('student_session_id');
        $action = isset($json['action']) ? $json['action'] : $this->input->post('action');
        $lat = isset($json['lat']) ? $json['lat'] : $this->input->post('lat');
        $lng = isset($json['lng']) ? $json['lng'] : $this->input->post('lng');
        $accuracy = isset($json['accuracy']) ? $json['accuracy'] : $this->input->post('accuracy');

        if (empty($student_session_id) || empty($action)) {
            $this->_error('student_session_id and action are required', 400);
            return;
        }

        if (!in_array($action, ['board', 'drop', 'missing'])) {
            $this->_error('action must be: board, drop, or missing', 400);
            return;
        }

        $vehicle_id = (int)$this->vehicle['id'];
        $trip_date = date('Y-m-d');
        $trip_type = $this->_getCurrentTripMode($vehicle_id, $trip_date);

        $result = $this->Smartbustracking_model->manualSetStatus(
            $vehicle_id,
            (int)$student_session_id,
            $action,
            $trip_date,
            $trip_type,
            $this->staff_id,
            $lat ? (float)$lat : null,
            $lng ? (float)$lng : null,
            $accuracy ? (float)$accuracy : null
        );

        if (!$result['success']) {
            $this->_error($result['message'], 400);
            return;
        }

        $this->_success([
            'message' => $result['message'],
            'action' => $action,
            'student_session_id' => (int)$student_session_id,
        ]);
    }

    /**
     * GET /smartbus/trip_mode
     */
    public function trip_mode()
    {
        if (!$this->_requireGet()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $vehicle_id = (int)$this->vehicle['id'];
        $trip_date = date('Y-m-d');
        $mode = $this->_getCurrentTripMode($vehicle_id, $trip_date);
        
        $this->_success([
            'mode' => $mode,
            'trip_date' => $trip_date,
            'auto_detected' => true,
        ]);
    }

    /**
     * POST /smartbus/trip_mode
     */
    public function set_trip_mode()
    {
        if (!$this->_requirePost()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $json = $this->_getJsonInput();
        $mode = isset($json['mode']) ? $json['mode'] : $this->input->post('mode');

        if (!in_array($mode, ['morning', 'afternoon'])) {
            $this->_error('mode must be: morning or afternoon', 400);
            return;
        }

        $vehicle_id = (int)$this->vehicle['id'];
        $trip_date = date('Y-m-d');

        // Store in session
        $session_key = "smartbus_mode_{$vehicle_id}_{$trip_date}";
        $this->session->set_userdata($session_key, $mode);

        $this->_success([
            'mode' => $mode,
            'trip_date' => $trip_date,
            'message' => 'Trip mode updated',
        ]);
    }

    /**
     * POST /smartbus/location
     */
    public function update_location()
    {
        if (!$this->_requirePost()) return;
        if (!$this->_authenticate()) return;
        if (!$this->_requireVehicle()) return;

        $json = $this->_getJsonInput();
        $lat = isset($json['lat']) ? $json['lat'] : $this->input->post('lat');
        $lng = isset($json['lng']) ? $json['lng'] : $this->input->post('lng');
        $accuracy = isset($json['accuracy']) ? $json['accuracy'] : $this->input->post('accuracy');
        $heading = isset($json['heading']) ? $json['heading'] : $this->input->post('heading');
        $speed = isset($json['speed']) ? $json['speed'] : $this->input->post('speed');

        if (empty($lat) || empty($lng)) {
            $this->_error('lat and lng are required', 400);
            return;
        }

        $vehicle_id = (int)$this->vehicle['id'];

        $this->Smartbustracking_model->upsertBusLocation(
            $vehicle_id,
            $this->staff_id,
            (float)$lat,
            (float)$lng,
            $accuracy ? (float)$accuracy : null,
            $heading ? (float)$heading : null,
            $speed ? (float)$speed : null
        );

        $this->_success([
            'message' => 'Location updated',
            'timestamp' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * GET /smartbus/location
     */
    public function get_location()
    {
        if (!$this->_requireGet()) return;
        if (!$this->_authenticate()) return;

        $vehicle_id = $this->input->get('vehicle_id');
        
        if (!$vehicle_id) {
            $vehicle = $this->Api_auth_model->getAssignedVehicle($this->staff_id);
            if ($vehicle) {
                $vehicle_id = $vehicle['id'];
            }
        }

        if (!$vehicle_id) {
            $this->_error('vehicle_id is required', 400);
            return;
        }

        $location = $this->Smartbustracking_model->getBusLocation((int)$vehicle_id);

        if (!$location) {
            $this->_notFound('No location data for this vehicle');
            return;
        }

        $updated_at = strtotime($location['updated_at']);
        $age_seconds = time() - $updated_at;
        $is_online = $age_seconds <= 20;

        $this->_success([
            'vehicle_id' => (int)$vehicle_id,
            'lat' => (float)$location['lat'],
            'lng' => (float)$location['lng'],
            'accuracy' => $location['accuracy'] ? (float)$location['accuracy'] : null,
            'heading' => $location['heading'] ? (float)$location['heading'] : null,
            'speed' => $location['speed'] ? (float)$location['speed'] : null,
            'updated_at' => $location['updated_at'],
            'age_seconds' => $age_seconds,
            'is_online' => $is_online,
        ]);
    }

    /**
     * Auto-detect trip type based on time
     */
    protected function _detectTripType()
    {
        $hour = (int)date('H');
        return $hour < 14 ? 'morning' : 'afternoon';
    }

    /**
     * Get current trip mode from session or auto-detect
     */
    protected function _getCurrentTripMode($vehicle_id, $trip_date)
    {
        $session_key = "smartbus_mode_{$vehicle_id}_{$trip_date}";
        $mode = $this->session->userdata($session_key);
        
        if ($mode && in_array($mode, ['morning', 'afternoon'])) {
            return $mode;
        }
        
        return $this->_detectTripType();
    }
}
