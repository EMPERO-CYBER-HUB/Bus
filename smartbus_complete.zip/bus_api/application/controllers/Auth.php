<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Authentication API Controller
 * 
 * Endpoints:
 * - POST /auth/login     - Login with email/password
 * - POST /auth/logout    - Logout (invalidate token)
 * - GET  /auth/me        - Get current staff profile
 */
class Auth extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        
        // Load encryption library from main application
        $this->load->library('Enc_lib', null, 'enc_lib');
    }

    /**
     * POST /auth/login
     */
    public function login()
    {
        if (!$this->_requirePost()) return;

        // Get input
        $json = $this->_getJsonInput();
        $email = isset($json['email']) ? trim($json['email']) : $this->input->post('email');
        $password = isset($json['password']) ? $json['password'] : $this->input->post('password');
        $device_info = isset($json['device_info']) ? $json['device_info'] : $this->input->post('device_info');

        // Validate
        if (empty($email) || empty($password)) {
            $this->_error('Email and password are required', 400);
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->_error('Invalid email format', 400);
            return;
        }

        // Get staff by email
        $staff = $this->Api_auth_model->getStaffByEmail($email);
        
        if (!$staff) {
            $this->_error('Invalid credentials', 401);
            return;
        }

        // Verify password
        $password_valid = $this->enc_lib->passHashDyc($password, $staff['password']);
        
        if (!$password_valid) {
            $this->_error('Invalid credentials', 401);
            return;
        }

        // Generate token
        $token_data = $this->Api_auth_model->createToken((int)$staff['id'], $device_info);

        // Get assigned vehicle
        $assigned_vehicle = $this->Api_auth_model->getAssignedVehicle((int)$staff['id']);

        // Build photo URLs
        $base_url = rtrim(str_replace('/bus_api/', '/', config_item('base_url')), '/');
        
        $photo_url = null;
        if (!empty($staff['image'])) {
            $photo_url = $base_url . '/uploads/staff_images/' . $staff['image'];
        }

        $vehicle_photo_url = null;
        if ($assigned_vehicle && !empty($assigned_vehicle['vehicle_photo'])) {
            $vehicle_photo_url = $base_url . '/uploads/vehicle_photo/' . $assigned_vehicle['vehicle_photo'];
        }

        $response_data = [
            'token' => $token_data['token'],
            'expires_at' => $token_data['expires_at'],
            'staff' => [
                'id' => (int)$staff['id'],
                'employee_id' => $staff['employee_id'] ?? '',
                'name' => trim(($staff['name'] ?? '') . ' ' . ($staff['surname'] ?? '')),
                'email' => $staff['email'],
                'contact_no' => $staff['contact_no'] ?? '',
                'role_id' => (int)($staff['role_id'] ?? 0),
                'role_name' => $staff['role_name'] ?? '',
                'photo_url' => $photo_url,
            ],
            'assigned_vehicle' => $assigned_vehicle ? [
                'id' => (int)$assigned_vehicle['id'],
                'vehicle_no' => $assigned_vehicle['vehicle_no'] ?? '',
                'vehicle_model' => $assigned_vehicle['vehicle_model'] ?? '',
                'driver_name' => $assigned_vehicle['driver_name'] ?? '',
                'driver_contact' => $assigned_vehicle['driver_contact'] ?? '',
                'photo_url' => $vehicle_photo_url,
            ] : null,
            'is_coordinator' => ($assigned_vehicle !== null),
        ];

        $this->_success($response_data, 'Login successful');
    }

    /**
     * POST /auth/logout
     */
    public function logout()
    {
        if (!$this->_requirePost()) return;
        if (!$this->_authenticate()) return;

        $this->Api_auth_model->invalidateToken($this->token);

        $this->_success(null, 'Logged out successfully');
    }

    /**
     * GET /auth/me
     */
    public function me()
    {
        if (!$this->_requireGet()) return;
        if (!$this->_authenticate()) return;

        $assigned_vehicle = $this->Api_auth_model->getAssignedVehicle($this->staff_id);

        // Build photo URLs
        $base_url = rtrim(str_replace('/bus_api/', '/', config_item('base_url')), '/');

        $photo_url = null;
        if (!empty($this->staff['image'])) {
            $photo_url = $base_url . '/uploads/staff_images/' . $this->staff['image'];
        }

        $vehicle_photo_url = null;
        if ($assigned_vehicle && !empty($assigned_vehicle['vehicle_photo'])) {
            $vehicle_photo_url = $base_url . '/uploads/vehicle_photo/' . $assigned_vehicle['vehicle_photo'];
        }

        $response_data = [
            'staff' => [
                'id' => (int)$this->staff['id'],
                'employee_id' => $this->staff['employee_id'] ?? '',
                'name' => trim(($this->staff['name'] ?? '') . ' ' . ($this->staff['surname'] ?? '')),
                'email' => $this->staff['email'],
                'contact_no' => $this->staff['contact_no'] ?? '',
                'role_id' => (int)($this->staff['role_id'] ?? 0),
                'role_name' => $this->staff['role_name'] ?? '',
                'photo_url' => $photo_url,
            ],
            'assigned_vehicle' => $assigned_vehicle ? [
                'id' => (int)$assigned_vehicle['id'],
                'vehicle_no' => $assigned_vehicle['vehicle_no'] ?? '',
                'vehicle_model' => $assigned_vehicle['vehicle_model'] ?? '',
                'driver_name' => $assigned_vehicle['driver_name'] ?? '',
                'driver_contact' => $assigned_vehicle['driver_contact'] ?? '',
                'photo_url' => $vehicle_photo_url,
            ] : null,
            'is_coordinator' => ($assigned_vehicle !== null),
        ];

        $this->_success($response_data);
    }
}
