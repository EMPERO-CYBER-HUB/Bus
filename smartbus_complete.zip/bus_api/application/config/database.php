<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Database Configuration
|--------------------------------------------------------------------------
| Use the same database as the main application
| Update these settings to match your main application's database config
*/

$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
    'dsn'          => '',
    'hostname'     => 'localhost',
    'username'     => 'empetkof_green',      // Your database username
    'password'     => '',                     // Your database password - UPDATE THIS
    'database'     => 'empetkof_green',      // Your database name
    'dbdriver'     => 'mysqli',
    'dbprefix'     => '',
    'pconnect'     => FALSE,
    'db_debug'     => (ENVIRONMENT !== 'production'),
    'cache_on'     => FALSE,
    'cachedir'     => '',
    'char_set'     => 'utf8mb4',
    'dbcollat'     => 'utf8mb4_unicode_ci',
    'swap_pre'     => '',
    'encrypt'      => FALSE,
    'compress'     => FALSE,
    'stricton'     => FALSE,
    'failover'     => array(),
    'save_queries' => TRUE
);

/*
|--------------------------------------------------------------------------
| IMPORTANT: Copy your database password from main application
|--------------------------------------------------------------------------
| 
| Open your main application's database config file:
| /application/config/database.php
| 
| Copy the 'password' value and paste it above.
|
*/
