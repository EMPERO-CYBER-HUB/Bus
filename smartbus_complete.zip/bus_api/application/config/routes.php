<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Smart Bus API Routes
|--------------------------------------------------------------------------
*/

// Default controller (not used - all routes are explicit)
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/*
|--------------------------------------------------------------------------
| Authentication Routes
|--------------------------------------------------------------------------
*/
$route['auth/login']['POST'] = 'auth/login';
$route['auth/logout']['POST'] = 'auth/logout';
$route['auth/me']['GET'] = 'auth/me';

/*
|--------------------------------------------------------------------------
| Smart Bus Routes
|--------------------------------------------------------------------------
*/
$route['smartbus/roster']['GET'] = 'smartbus/roster';
$route['smartbus/status']['GET'] = 'smartbus/status';
$route['smartbus/checkin']['POST'] = 'smartbus/checkin';
$route['smartbus/manual_status']['POST'] = 'smartbus/manual_status';
$route['smartbus/trip_mode']['GET'] = 'smartbus/trip_mode';
$route['smartbus/trip_mode']['POST'] = 'smartbus/set_trip_mode';
$route['smartbus/location']['POST'] = 'smartbus/update_location';
$route['smartbus/location']['GET'] = 'smartbus/get_location';

/*
|--------------------------------------------------------------------------
| Fallback route - return JSON error
|--------------------------------------------------------------------------
*/
// Handled by 404_override or default controller
