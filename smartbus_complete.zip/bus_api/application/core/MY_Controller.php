<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * API Base Controller
 * 
 * All API controllers should extend this class
 * Provides authentication and JSON response helpers
 */
class MY_Controller extends CI_Controller
{
    protected $staff_id = null;
    protected $staff = null;
    protected $token = null;

    public function __construct()
    {
        parent::__construct();
        
        // Set JSON content type
        header('Content-Type: application/json; charset=UTF-8');
        
        // Handle CORS
        $this->_handleCors();
        
        // Load API auth model
        $this->load->model('Api_auth_model');
    }

    /**
     * Handle CORS headers
     */
    protected function _handleCors()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
        
        // Handle preflight request
        if ($this->input->method() === 'options') {
            http_response_code(200);
            exit();
        }
    }

    /**
     * Authenticate request using Bearer token
     */
    protected function _authenticate()
    {
        $auth_header = $this->input->get_request_header('Authorization');
        
        if (empty($auth_header)) {
            $this->_unauthorized('Missing Authorization header');
            return false;
        }

        if (!preg_match('/^Bearer\s+(.+)$/i', $auth_header, $matches)) {
            $this->_unauthorized('Invalid Authorization format. Use: Bearer <token>');
            return false;
        }

        $this->token = trim($matches[1]);
        $this->staff_id = $this->Api_auth_model->validateToken($this->token);

        if (!$this->staff_id) {
            $this->_unauthorized('Invalid or expired token');
            return false;
        }

        $this->staff = $this->Api_auth_model->getStaffById($this->staff_id);
        
        if (!$this->staff) {
            $this->_unauthorized('Staff account not found or inactive');
            return false;
        }

        return true;
    }

    /**
     * Send JSON response
     */
    protected function _response($data, $status_code = 200)
    {
        http_response_code($status_code);
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit();
    }

    /**
     * Send success response
     */
    protected function _success($data = null, $message = 'Success')
    {
        $response = [
            'status' => 1,
            'message' => $message,
        ];
        
        if ($data !== null) {
            $response['data'] = $data;
        }

        $this->_response($response, 200);
    }

    /**
     * Send error response
     */
    protected function _error($message, $status_code = 400, $errors = null)
    {
        $response = [
            'status' => 0,
            'message' => $message,
        ];
        
        if ($errors !== null) {
            $response['errors'] = $errors;
        }

        $this->_response($response, $status_code);
    }

    /**
     * Send unauthorized response
     */
    protected function _unauthorized($message = 'Unauthorized')
    {
        $this->_error($message, 401);
    }

    /**
     * Send forbidden response
     */
    protected function _forbidden($message = 'Forbidden')
    {
        $this->_error($message, 403);
    }

    /**
     * Send not found response
     */
    protected function _notFound($message = 'Not found')
    {
        $this->_error($message, 404);
    }

    /**
     * Get JSON body from request
     */
    protected function _getJsonInput()
    {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }

    /**
     * Require POST method
     */
    protected function _requirePost()
    {
        if ($this->input->method() !== 'post') {
            $this->_error('Method not allowed. Use POST.', 405);
            return false;
        }
        return true;
    }

    /**
     * Require GET method
     */
    protected function _requireGet()
    {
        if ($this->input->method() !== 'get') {
            $this->_error('Method not allowed. Use GET.', 405);
            return false;
        }
        return true;
    }
}
