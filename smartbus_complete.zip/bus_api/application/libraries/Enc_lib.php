<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Encryption Library Wrapper
 * 
 * This loads and uses the encryption library from the main application
 */
class Enc_lib
{
    private $CI;
    private $main_enc_lib = null;

    public function __construct()
    {
        $this->CI =& get_instance();
        
        // Try to load the main application's Enc_lib
        $main_app_path = realpath(FCPATH . '../application');
        
        if ($main_app_path && file_exists($main_app_path . '/libraries/Enc_lib.php')) {
            require_once($main_app_path . '/libraries/Enc_lib.php');
            $this->main_enc_lib = new \Enc_lib();
        }
    }

    /**
     * Verify password against hash
     * 
     * @param string $password Plain text password
     * @param string $hash Stored hash
     * @return bool
     */
    public function passHashDyc($password, $hash)
    {
        if ($this->main_enc_lib && method_exists($this->main_enc_lib, 'passHashDyc')) {
            return $this->main_enc_lib->passHashDyc($password, $hash);
        }
        
        // Fallback: Try common verification methods
        // Method 1: password_verify (if hash is bcrypt)
        if (password_verify($password, $hash)) {
            return true;
        }
        
        // Method 2: MD5 comparison (legacy)
        if (md5($password) === $hash) {
            return true;
        }
        
        // Method 3: SHA256 comparison
        if (hash('sha256', $password) === $hash) {
            return true;
        }
        
        // Method 4: Direct comparison (plain text - not recommended)
        if ($password === $hash) {
            return true;
        }
        
        return false;
    }

    /**
     * Hash password
     */
    public function passHashEnc($password)
    {
        if ($this->main_enc_lib && method_exists($this->main_enc_lib, 'passHashEnc')) {
            return $this->main_enc_lib->passHashEnc($password);
        }
        
        // Fallback: Use bcrypt
        return password_hash($password, PASSWORD_BCRYPT);
    }
}
