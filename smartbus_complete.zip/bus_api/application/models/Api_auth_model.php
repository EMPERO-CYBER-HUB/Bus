<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * API Authentication Model
 * 
 * Handles token generation, validation, and staff lookup
 */
class Api_auth_model extends CI_Model
{
    const TOKEN_EXPIRY_DAYS = 30;

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Generate a secure random token
     */
    public function generateToken()
    {
        return bin2hex(random_bytes(32));
    }

    /**
     * Create a new token for staff
     */
    public function createToken($staff_id, $device_info = null)
    {
        $token = $this->generateToken();
        $now = date('Y-m-d H:i:s');
        $expires = date('Y-m-d H:i:s', strtotime('+' . self::TOKEN_EXPIRY_DAYS . ' days'));

        $data = [
            'staff_id'    => $staff_id,
            'token'       => $token,
            'device_info' => $device_info,
            'created_at'  => $now,
            'expires_at'  => $expires,
            'last_used_at'=> $now,
            'is_active'   => 1,
        ];

        $this->db->insert('api_tokens', $data);

        return [
            'token'      => $token,
            'expires_at' => $expires,
        ];
    }

    /**
     * Validate token and return staff_id if valid
     */
    public function validateToken($token)
    {
        $row = $this->db->select('id, staff_id, expires_at, is_active')
            ->from('api_tokens')
            ->where('token', $token)
            ->limit(1)
            ->get()
            ->row_array();

        if (!$row) {
            return null;
        }

        if ((int)$row['is_active'] !== 1) {
            return null;
        }

        if (strtotime($row['expires_at']) < time()) {
            $this->db->where('id', $row['id'])->update('api_tokens', ['is_active' => 0]);
            return null;
        }

        // Update last_used_at
        $this->db->where('id', $row['id'])->update('api_tokens', ['last_used_at' => date('Y-m-d H:i:s')]);

        return (int)$row['staff_id'];
    }

    /**
     * Invalidate a specific token (logout)
     */
    public function invalidateToken($token)
    {
        $this->db->where('token', $token)->update('api_tokens', ['is_active' => 0]);
        return $this->db->affected_rows() > 0;
    }

    /**
     * Invalidate all tokens for a staff member
     */
    public function invalidateAllTokens($staff_id)
    {
        $this->db->where('staff_id', $staff_id)->update('api_tokens', ['is_active' => 0]);
    }

    /**
     * Get staff by email
     */
    public function getStaffByEmail($email)
    {
        $row = $this->db->select('staff.*, roles.name as role_name, roles.id as role_id')
            ->from('staff')
            ->join('staff_roles', 'staff_roles.staff_id = staff.id', 'left')
            ->join('roles', 'roles.id = staff_roles.role_id', 'left')
            ->where('staff.email', $email)
            ->where('staff.is_active', 1)
            ->limit(1)
            ->get()
            ->row_array();

        return $row ?: null;
    }

    /**
     * Get staff by ID
     */
    public function getStaffById($staff_id)
    {
        $row = $this->db->select('staff.id, staff.employee_id, staff.name, staff.surname, staff.email, staff.contact_no, staff.image, roles.name as role_name, roles.id as role_id')
            ->from('staff')
            ->join('staff_roles', 'staff_roles.staff_id = staff.id', 'left')
            ->join('roles', 'roles.id = staff_roles.role_id', 'left')
            ->where('staff.id', $staff_id)
            ->where('staff.is_active', 1)
            ->limit(1)
            ->get()
            ->row_array();

        return $row ?: null;
    }

    /**
     * Get assigned vehicle for coordinator
     * Vehicle.chasis_number stores the coordinator staff_id
     */
    public function getAssignedVehicle($staff_id)
    {
        $row = $this->db->select('id, vehicle_no, vehicle_model, driver_name, driver_contact, vehicle_photo')
            ->from('vehicles')
            ->where('chasis_number', (string)$staff_id)
            ->limit(1)
            ->get()
            ->row_array();

        return $row ?: null;
    }

    /**
     * Clean up expired tokens (call periodically via cron)
     */
    public function cleanupExpiredTokens()
    {
        $this->db->where('expires_at <', date('Y-m-d H:i:s'))
            ->or_where('is_active', 0)
            ->delete('api_tokens');

        return $this->db->affected_rows();
    }
}
