package com.greenyouth.smartbus.ui.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.LoginData
import com.greenyouth.smartbus.data.LoginRequest
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    
    private val sessionManager = SessionManager(application)
    private val apiService = ApiClient.getService(application)
    
    private val _loginState = MutableLiveData<LoginState>()
    val loginState: LiveData<LoginState> = _loginState
    
    fun login(email: String, password: String) {
        _loginState.value = LoginState.Loading
        
        viewModelScope.launch {
            try {
                val response = apiService.login(LoginRequest(email, password))
                
                if (response.isSuccessful && response.body()?.status == 1) {
                    val data = response.body()?.data
                    if (data != null) {
                        saveSession(data)
                        _loginState.value = LoginState.Success(data)
                    } else {
                        _loginState.value = LoginState.Error("Invalid response")
                    }
                } else {
                    val errorMsg = response.body()?.message ?: "Login failed"
                    _loginState.value = LoginState.Error(errorMsg)
                }
            } catch (e: Exception) {
                _loginState.value = LoginState.Error(e.message ?: "Network error")
            }
        }
    }
    
    private fun saveSession(data: LoginData) {
        sessionManager.saveToken(data.token)
        data.staff?.let { sessionManager.saveStaff(it) }
        data.assignedVehicle?.let { sessionManager.saveVehicle(it) }
        sessionManager.saveIsCoordinator(data.isCoordinator)
    }
    
    sealed class LoginState {
        object Idle : LoginState()
        object Loading : LoginState()
        data class Success(val data: LoginData) : LoginState()
        data class Error(val message: String) : LoginState()
    }
}
