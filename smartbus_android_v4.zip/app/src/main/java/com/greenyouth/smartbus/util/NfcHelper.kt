package com.greenyouth.smartbus.util

import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag

object NfcHelper {
    
    fun getTagUid(intent: Intent): String? {
        if (intent.action != NfcAdapter.ACTION_TECH_DISCOVERED &&
            intent.action != NfcAdapter.ACTION_TAG_DISCOVERED &&
            intent.action != NfcAdapter.ACTION_NDEF_DISCOVERED) {
            return null
        }
        
        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG) ?: return null
        return bytesToHex(tag.id)
    }
    
    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString(":") { "%02X".format(it) }
    }
}
