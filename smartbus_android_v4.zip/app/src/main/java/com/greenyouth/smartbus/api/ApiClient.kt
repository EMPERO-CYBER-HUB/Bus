package com.greenyouth.smartbus.api

import android.content.Context
import com.greenyouth.smartbus.BuildConfig
import com.greenyouth.smartbus.util.SessionManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    
    private var retrofit: Retrofit? = null
    private var apiService: ApiService? = null
    
    fun getService(context: Context): ApiService {
        if (apiService == null) {
            apiService = getRetrofit(context).create(ApiService::class.java)
        }
        return apiService!!
    }
    
    private fun getRetrofit(context: Context): Retrofit {
        if (retrofit == null) {
            val sessionManager = SessionManager(context)
            
            val authInterceptor = Interceptor { chain ->
                val original = chain.request()
                val token = sessionManager.getToken()
                
                val request = if (token != null) {
                    original.newBuilder()
                        .header("Authorization", "Bearer $token")
                        .header("Accept", "application/json")
                        .build()
                } else {
                    original.newBuilder()
                        .header("Accept", "application/json")
                        .build()
                }
                
                chain.proceed(request)
            }
            
            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = if (BuildConfig.DEBUG) {
                    HttpLoggingInterceptor.Level.BODY
                } else {
                    HttpLoggingInterceptor.Level.NONE
                }
            }
            
            val client = OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .addInterceptor(loggingInterceptor)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build()
            
            retrofit = Retrofit.Builder()
                .baseUrl(BuildConfig.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofit!!
    }
    
    fun reset() {
        retrofit = null
        apiService = null
    }
}
