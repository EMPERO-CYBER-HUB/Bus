package com.greenyouth.smartbus.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.data.StudentItem
import com.greenyouth.smartbus.data.StudentStatus
import com.greenyouth.smartbus.databinding.ItemStudentBinding
import java.text.SimpleDateFormat
import java.util.*

class StudentAdapter(
    private val onItemClick: (StudentItem) -> Unit
) : ListAdapter<StudentItem, StudentAdapter.ViewHolder>(DiffCallback()) {
    
    private var statusMap: Map<String, StudentStatus> = emptyMap()
    
    fun updateStatusMap(map: Map<String, StudentStatus>) {
        statusMap = map
        notifyDataSetChanged()
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemStudentBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), statusMap)
    }
    
    inner class ViewHolder(
        private val binding: ItemStudentBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        
        private val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
        private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        
        fun bind(student: StudentItem, statusMap: Map<String, StudentStatus>) {
            val context = binding.root.context
            val status = statusMap[student.studentSessionId.toString()]
            
            // Name and class
            binding.tvStudentName.text = student.fullName
            binding.tvClass.text = student.classSection
            
            // Guardian info
            binding.tvGuardian.text = student.guardianLabel.ifBlank { "-" }
            binding.tvPhone.text = student.guardianPhone ?: "-"
            binding.tvPickupPoint.text = student.pickupPoint ?: "-"
            
            // Photo
            if (!student.photoUrl.isNullOrBlank()) {
                binding.ivStudentPhoto.load(student.photoUrl) {
                    placeholder(R.drawable.ic_person)
                    error(R.drawable.ic_person)
                    transformations(CircleCropTransformation())
                }
            } else {
                binding.ivStudentPhoto.setImageResource(R.drawable.ic_person)
            }
            
            // Status
            val hasBoarded = !status?.boardedAt.isNullOrBlank()
            val hasDropped = !status?.droppedAt.isNullOrBlank()
            
            when {
                hasDropped -> {
                    binding.tvStatus.text = context.getString(R.string.dropped)
                    binding.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_dropped))
                    binding.tvStatus.setBackgroundResource(R.drawable.bg_status_dropped)
                }
                hasBoarded -> {
                    binding.tvStatus.text = context.getString(R.string.on_bus)
                    binding.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_on_bus))
                    binding.tvStatus.setBackgroundResource(R.drawable.bg_status_on_bus)
                }
                else -> {
                    binding.tvStatus.text = context.getString(R.string.missing)
                    binding.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_missing))
                    binding.tvStatus.setBackgroundResource(R.drawable.bg_status_missing)
                }
            }
            
            // Times
            binding.tvBoardedTime.text = formatTime(status?.boardedAt)
            binding.tvDroppedTime.text = formatTime(status?.droppedAt)
            
            // Click listener
            binding.root.setOnClickListener {
                onItemClick(student)
            }
        }
        
        private fun formatTime(dateStr: String?): String {
            if (dateStr.isNullOrBlank()) return "—"
            return try {
                val date = dateTimeFormat.parse(dateStr)
                if (date != null) timeFormat.format(date) else "—"
            } catch (e: Exception) {
                "—"
            }
        }
    }
    
    class DiffCallback : DiffUtil.ItemCallback<StudentItem>() {
        override fun areItemsTheSame(oldItem: StudentItem, newItem: StudentItem): Boolean {
            return oldItem.studentSessionId == newItem.studentSessionId
        }
        
        override fun areContentsTheSame(oldItem: StudentItem, newItem: StudentItem): Boolean {
            return oldItem == newItem
        }
    }
}
