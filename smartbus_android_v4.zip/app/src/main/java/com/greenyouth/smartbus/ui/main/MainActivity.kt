package com.greenyouth.smartbus.ui.main

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.gms.location.*
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.databinding.ActivityMainBinding
import com.greenyouth.smartbus.service.LocationService
import com.greenyouth.smartbus.ui.login.LoginActivity
import com.greenyouth.smartbus.util.LocaleHelper
import com.greenyouth.smartbus.util.NfcHelper
import com.greenyouth.smartbus.util.SessionManager

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: StudentAdapter
    private lateinit var sessionManager: SessionManager
    
    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var locationCallback: LocationCallback? = null
    
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            startLocationUpdates()
        }
    }
    
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        
        setupNfc()
        setupViews()
        setupRecyclerView()
        observeViewModel()
        
        viewModel.loadRoster()
        checkLocationPermission()
    }
    
    override fun onResume() {
        super.onResume()
        enableNfcForeground()
        viewModel.startAutoRefresh()
    }
    
    override fun onPause() {
        super.onPause()
        disableNfcForeground()
        viewModel.stopAutoRefresh()
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleNfcIntent(intent)
    }
    
    private fun setupNfc() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_MUTABLE
        )
    }
    
    private fun enableNfcForeground() {
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, null, null)
    }
    
    private fun disableNfcForeground() {
        nfcAdapter?.disableForegroundDispatch(this)
    }
    
    private fun handleNfcIntent(intent: Intent) {
        val uid = NfcHelper.getTagUid(intent)
        if (uid != null) {
            vibrate(50)
            binding.tvLastUid.text = uid
            
            // Get current location for checkin
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
                == PackageManager.PERMISSION_GRANTED) {
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    viewModel.checkin(
                        uid,
                        location?.latitude,
                        location?.longitude,
                        location?.accuracy
                    )
                }
            } else {
                viewModel.checkin(uid, null, null, null)
            }
        }
    }
    
    private fun setupViews() {
        val vehicle = viewModel.vehicle
        val staff = viewModel.staff
        
        // Header
        binding.tvVehicleNo.text = vehicle?.vehicleNo ?: "-"
        binding.tvDriverName.text = getString(R.string.driver) + ": " + (vehicle?.driverName ?: "-")
        
        // Load bus photo
        if (!vehicle?.photoUrl.isNullOrBlank()) {
            binding.ivBusPhoto.load(vehicle?.photoUrl) {
                placeholder(R.drawable.ic_bus)
                error(R.drawable.ic_bus)
            }
        }
        
        // Menu button - staff photo is INSIDE the popup
        binding.btnMenu.setOnClickListener { showMenu(it) }
        
        // Trip mode button
        binding.btnTripMode.setOnClickListener {
            viewModel.toggleTripMode()
        }
        
        // Swipe refresh
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadRoster()
        }
        
        binding.swipeRefresh.setColorSchemeResources(R.color.primary)
    }
    
    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        
        // Add header with staff photo (custom approach via alert dialog)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)
        
        // Update language menu item to show current language only
        val langItem = popup.menu.findItem(R.id.menu_language)
        val currentLang = LocaleHelper.getLanguageDisplayName(LocaleHelper.getLanguage(this))
        langItem.title = getString(R.string.language) + ": " + currentLang
        
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_language -> {
                    showLanguageDialog()
                    true
                }
                R.id.menu_logout -> {
                    showLogoutDialog()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
    
    private fun showLanguageDialog() {
        val languages = LocaleHelper.getSupportedLanguages()
        val currentLang = LocaleHelper.getLanguage(this)
        val currentIndex = languages.indexOfFirst { it.first == currentLang }.coerceAtLeast(0)
        
        val items = languages.map { it.second }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle(R.string.select_language)
            .setSingleChoiceItems(items, currentIndex) { dialog, which ->
                val selectedLang = languages[which].first
                if (selectedLang != currentLang) {
                    LocaleHelper.setLocale(this, selectedLang)
                    recreate()
                }
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    
    private fun showLogoutDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.logout)
            .setMessage(R.string.confirm_logout)
            .setPositiveButton(R.string.yes) { _, _ ->
                viewModel.logout()
                stopLocationUpdates()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }
    
    private fun setupRecyclerView() {
        adapter = StudentAdapter(
            onItemClick = { student ->
                showStatusMenu(student)
            }
        )
        binding.rvStudents.layoutManager = LinearLayoutManager(this)
        binding.rvStudents.adapter = adapter
    }
    
    private fun showStatusMenu(student: com.greenyouth.smartbus.data.StudentItem) {
        val ssid = student.studentSessionId
        val status = viewModel.statusMap.value?.get(ssid.toString())
        
        val hasBoarded = !status?.boardedAt.isNullOrBlank()
        val hasDropped = !status?.droppedAt.isNullOrBlank()
        
        val items = mutableListOf<Pair<String, String>>()
        
        if (!hasBoarded) {
            items.add(getString(R.string.board) to "board")
        }
        if (hasBoarded && !hasDropped) {
            items.add(getString(R.string.drop) to "drop")
            items.add(getString(R.string.mark_missing) to "missing")
        }
        if (hasDropped) {
            items.add(getString(R.string.board) to "board")
            items.add(getString(R.string.mark_missing) to "missing")
        }
        if (!hasBoarded && !hasDropped) {
            // Already missing, can only board
        }
        
        if (items.isEmpty()) {
            items.add(getString(R.string.board) to "board")
        }
        
        AlertDialog.Builder(this)
            .setTitle(student.fullName)
            .setItems(items.map { it.first }.toTypedArray()) { _, which ->
                val target = items[which].second
                viewModel.setManualStatus(ssid, target)
            }
            .show()
    }
    
    private fun observeViewModel() {
        viewModel.students.observe(this) { students ->
            adapter.submitList(students)
            binding.tvEmptyList.visibility = if (students.isEmpty()) View.VISIBLE else View.GONE
            updateStats()
        }
        
        viewModel.statusMap.observe(this) { statusMap ->
            adapter.updateStatusMap(statusMap)
            updateStats()
        }
        
        viewModel.tripMode.observe(this) { mode ->
            updateTripModeUI(mode)
        }
        
        viewModel.isLoading.observe(this) { isLoading ->
            binding.swipeRefresh.isRefreshing = isLoading
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
        
        viewModel.scanResult.observe(this) { result ->
            if (result != null) {
                showScanResult(result)
                viewModel.clearScanResult()
            }
        }
        
        viewModel.error.observe(this) { error ->
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }
    
    private fun updateTripModeUI(mode: String) {
        val isDropMode = mode == "drop"
        
        binding.tvModeStatus.text = if (isDropMode) {
            getString(R.string.drop_mode)
        } else {
            getString(R.string.pickup_mode)
        }
        
        binding.btnTripMode.text = if (isDropMode) {
            getString(R.string.stop_moving)
        } else {
            getString(R.string.start_moving)
        }
        
        binding.ivModeIndicator.setColorFilter(
            ContextCompat.getColor(this, if (isDropMode) R.color.status_dropped else R.color.status_on_bus)
        )
    }
    
    private fun updateStats() {
        val students = viewModel.students.value ?: emptyList()
        val statusMap = viewModel.statusMap.value ?: emptyMap()
        
        val total = students.size
        var onBus = 0
        var dropped = 0
        
        for (student in students) {
            val status = statusMap[student.studentSessionId.toString()]
            if (!status?.droppedAt.isNullOrBlank()) {
                dropped++
                onBus++
            } else if (!status?.boardedAt.isNullOrBlank()) {
                onBus++
            }
        }
        
        val missing = total - onBus
        
        binding.tvTotal.text = total.toString()
        binding.tvOnBus.text = onBus.toString()
        binding.tvDropped.text = dropped.toString()
        binding.tvMissing.text = missing.toString()
    }
    
    private fun showScanResult(result: MainViewModel.ScanResult) {
        binding.cardScanResult.visibility = View.VISIBLE
        
        val bgColor: Int
        val textColor: Int
        
        when {
            !result.success -> {
                bgColor = R.color.scan_error_bg
                textColor = R.color.status_missing
                binding.ivScanIcon.setImageResource(R.drawable.ic_person)
                vibrate(longArrayOf(0, 100, 50, 100))
            }
            result.isAlready -> {
                bgColor = R.color.scan_warning_bg
                textColor = R.color.status_warning
                binding.ivScanIcon.setImageResource(R.drawable.ic_person)
                vibrate(longArrayOf(0, 100, 50, 100))
            }
            result.code == "DROP_OK" || result.code == "DROPPED" -> {
                bgColor = R.color.bg_dropped
                textColor = R.color.status_dropped
                binding.ivScanIcon.setImageResource(R.drawable.ic_person)
                vibrate(40)
            }
            else -> {
                bgColor = R.color.scan_success_bg
                textColor = R.color.status_on_bus
                binding.ivScanIcon.setImageResource(R.drawable.ic_person)
                vibrate(40)
            }
        }
        
        binding.cardScanResult.setCardBackgroundColor(ContextCompat.getColor(this, bgColor))
        binding.tvScanTitle.text = result.message
        binding.tvScanTitle.setTextColor(ContextCompat.getColor(this, textColor))
        binding.tvScanMessage.text = result.studentName ?: ""
        
        // Auto hide after 5 seconds
        binding.cardScanResult.postDelayed({
            binding.cardScanResult.visibility = View.GONE
        }, 5000)
    }
    
    private fun vibrate(duration: Long) {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    }
    
    private fun vibrate(pattern: LongArray) {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }
    
    private fun checkLocationPermission() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
                == PackageManager.PERMISSION_GRANTED -> {
                startLocationUpdates()
            }
            else -> {
                locationPermissionLauncher.launch(arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ))
            }
        }
    }
    
    private fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
            != PackageManager.PERMISSION_GRANTED) return
        
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000)
            .setMinUpdateIntervalMillis(3000)
            .build()
        
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { location ->
                    viewModel.updateLocation(
                        location.latitude,
                        location.longitude,
                        location.accuracy,
                        if (location.hasBearing()) location.bearing else null,
                        if (location.hasSpeed()) location.speed else null
                    )
                }
            }
        }
        
        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback!!,
            mainLooper
        )
    }
    
    private fun stopLocationUpdates() {
        locationCallback?.let {
            fusedLocationClient.removeLocationUpdates(it)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopLocationUpdates()
    }
}
