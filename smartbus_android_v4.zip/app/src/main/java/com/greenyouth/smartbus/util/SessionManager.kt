package com.greenyouth.smartbus.util

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.greenyouth.smartbus.data.Staff
import com.greenyouth.smartbus.data.Vehicle

class SessionManager(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val PREFS_NAME = "smartbus_prefs"
        private const val KEY_TOKEN = "token"
        private const val KEY_STAFF = "staff"
        private const val KEY_VEHICLE = "vehicle"
        private const val KEY_IS_COORDINATOR = "is_coordinator"
        private const val KEY_TRIP_MODE = "trip_mode"
    }
    
    fun saveToken(token: String) {
        prefs.edit().putString(KEY_TOKEN, token).apply()
    }
    
    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)
    
    fun saveStaff(staff: Staff) {
        prefs.edit().putString(KEY_STAFF, gson.toJson(staff)).apply()
    }
    
    fun getStaff(): Staff? {
        val json = prefs.getString(KEY_STAFF, null) ?: return null
        return try {
            gson.fromJson(json, Staff::class.java)
        } catch (e: Exception) {
            null
        }
    }
    
    fun saveVehicle(vehicle: Vehicle) {
        prefs.edit().putString(KEY_VEHICLE, gson.toJson(vehicle)).apply()
    }
    
    fun getVehicle(): Vehicle? {
        val json = prefs.getString(KEY_VEHICLE, null) ?: return null
        return try {
            gson.fromJson(json, Vehicle::class.java)
        } catch (e: Exception) {
            null
        }
    }
    
    fun saveIsCoordinator(isCoordinator: Boolean) {
        prefs.edit().putBoolean(KEY_IS_COORDINATOR, isCoordinator).apply()
    }
    
    fun isCoordinator(): Boolean = prefs.getBoolean(KEY_IS_COORDINATOR, false)
    
    fun saveTripMode(mode: String) {
        prefs.edit().putString(KEY_TRIP_MODE, mode).apply()
    }
    
    fun getTripMode(): String = prefs.getString(KEY_TRIP_MODE, "pickup") ?: "pickup"
    
    fun isLoggedIn(): Boolean = getToken() != null
    
    fun clear() {
        prefs.edit().clear().apply()
    }
}
