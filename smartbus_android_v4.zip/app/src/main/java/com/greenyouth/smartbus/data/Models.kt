package com.greenyouth.smartbus.data

import com.google.gson.annotations.SerializedName

// Login
data class LoginRequest(
    val email: String,
    val password: String,
    @SerializedName("device_info") val deviceInfo: String? = null
)

data class LoginResponse(
    val status: Int,
    val message: String?,
    val data: LoginData?
)

data class LoginData(
    val token: String,
    @SerializedName("expires_at") val expiresAt: String?,
    val staff: Staff?,
    @SerializedName("assigned_vehicle") val assignedVehicle: Vehicle?,
    @SerializedName("is_coordinator") val isCoordinator: Boolean = false
)

data class Staff(
    val id: Int,
    @SerializedName("employee_id") val employeeId: String?,
    val name: String?,
    val email: String?,
    @SerializedName("contact_no") val contactNo: String?,
    @SerializedName("role_id") val roleId: Int?,
    @SerializedName("role_name") val roleName: String?,
    @SerializedName("photo_url") val photoUrl: String?
)

data class Vehicle(
    val id: Int,
    @SerializedName("vehicle_no") val vehicleNo: String?,
    @SerializedName("vehicle_model") val vehicleModel: String?,
    @SerializedName("driver_name") val driverName: String?,
    @SerializedName("driver_contact") val driverContact: String?,
    @SerializedName("photo_url") val photoUrl: String?
)

// Roster
data class RosterResponse(
    val status: Int,
    val message: String?,
    val data: RosterData?
)

data class RosterData(
    val students: List<StudentItem>?,
    @SerializedName("status_map") val statusMap: Map<String, StudentStatus>?,
    @SerializedName("trip_mode") val tripMode: String?,
    @SerializedName("trip_date") val tripDate: String?,
    @SerializedName("trip_type") val tripType: String?
)

data class StudentItem(
    @SerializedName("student_session_id") val studentSessionId: Int,
    @SerializedName("student_id") val studentId: Int?,
    val firstname: String?,
    val middlename: String?,
    val lastname: String?,
    @SerializedName("class_name") val className: String?,
    @SerializedName("section_name") val sectionName: String?,
    @SerializedName("guardian_name") val guardianName: String?,
    @SerializedName("guardian_phone") val guardianPhone: String?,
    @SerializedName("guardian_relation") val guardianRelation: String?,
    @SerializedName("pickup_point") val pickupPoint: String?,
    @SerializedName("photo_url") val photoUrl: String?,
    @SerializedName("card_uid") val cardUid: String?
) {
    val fullName: String
        get() = listOfNotNull(firstname, middlename, lastname)
            .filter { it.isNotBlank() }
            .joinToString(" ")
    
    val classSection: String
        get() = buildString {
            append(className ?: "")
            if (!sectionName.isNullOrBlank()) {
                append(" ($sectionName)")
            }
        }
    
    val guardianLabel: String
        get() = buildString {
            if (!guardianRelation.isNullOrBlank()) {
                append(guardianRelation.uppercase())
                append(" - ")
            }
            append(guardianName ?: "")
        }
}

data class StudentStatus(
    @SerializedName("checked_in_at") val checkedInAt: String?,
    @SerializedName("boarded_at") val boardedAt: String?,
    @SerializedName("dropped_at") val droppedAt: String?
)

// Status
data class StatusResponse(
    val status: Int,
    val mode: String?,
    @SerializedName("status_map") val statusMap: Map<String, StudentStatus>?
)

// Trip Mode
data class TripModeRequest(
    @SerializedName("vehicle_id") val vehicleId: Int,
    @SerializedName("trip_date") val tripDate: String,
    @SerializedName("trip_type") val tripType: String,
    val mode: String
)

data class TripModeResponse(
    val status: Int,
    val message: String?,
    val mode: String?
)

// Checkin
data class CheckinRequest(
    @SerializedName("vehicle_id") val vehicleId: Int,
    @SerializedName("trip_date") val tripDate: String,
    @SerializedName("trip_type") val tripType: String,
    val uid: String,
    val lat: Double?,
    val lng: Double?,
    val accuracy: Float?
)

data class CheckinResponse(
    val status: Int,
    val message: String?,
    val code: String?,
    val already: Int?,
    @SerializedName("trip_mode") val tripMode: String?,
    val student: CheckinStudent?,
    val state: StudentStatus?
)

data class CheckinStudent(
    @SerializedName("student_session_id") val studentSessionId: Int,
    val name: String?
)

// Manual Status
data class ManualStatusRequest(
    @SerializedName("vehicle_id") val vehicleId: Int,
    @SerializedName("trip_date") val tripDate: String,
    @SerializedName("trip_type") val tripType: String,
    @SerializedName("student_session_id") val studentSessionId: Int,
    val target: String
)

data class ManualStatusResponse(
    val status: Int,
    val message: String?,
    val code: String?,
    val state: StudentStatus?
)

// Location
data class LocationUpdateRequest(
    @SerializedName("vehicle_id") val vehicleId: Int,
    val lat: Double,
    val lng: Double,
    val accuracy: Float?,
    val heading: Float?,
    val speed: Float?
)

data class LocationResponse(
    val status: Int,
    val message: String?,
    val data: LocationData?
)

data class LocationData(
    val lat: Double?,
    val lng: Double?,
    val accuracy: Float?,
    val heading: Float?,
    val speed: Float?,
    @SerializedName("updated_at") val updatedAt: String?
)

// Generic
data class ApiResponse(
    val status: Int,
    val message: String?
)
