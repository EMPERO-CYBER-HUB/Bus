package com.greenyouth.smartbus.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.*
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {
    
    private val sessionManager = SessionManager(application)
    private val apiService = ApiClient.getService(application)
    
    private val _students = MutableLiveData<List<StudentItem>>()
    val students: LiveData<List<StudentItem>> = _students
    
    private val _statusMap = MutableLiveData<Map<String, StudentStatus>>()
    val statusMap: LiveData<Map<String, StudentStatus>> = _statusMap
    
    private val _tripMode = MutableLiveData<String>()
    val tripMode: LiveData<String> = _tripMode
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _scanResult = MutableLiveData<ScanResult?>()
    val scanResult: LiveData<ScanResult?> = _scanResult
    
    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error
    
    private var refreshJob: Job? = null
    
    val vehicle: Vehicle? get() = sessionManager.getVehicle()
    val staff: Staff? get() = sessionManager.getStaff()
    val vehicleId: Int get() = vehicle?.id ?: 0
    
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    
    fun getTripDate(): String = dateFormat.format(Date())
    
    fun getTripType(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (hour < 14) "morning" else "afternoon"
    }
    
    init {
        _tripMode.value = sessionManager.getTripMode()
    }
    
    fun loadRoster() {
        if (vehicleId <= 0) return
        
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val response = apiService.getRoster(vehicleId, getTripDate(), getTripType())
                if (response.isSuccessful && response.body()?.status == 1) {
                    val data = response.body()?.data
                    _students.value = data?.students ?: emptyList()
                    _statusMap.value = data?.statusMap ?: emptyMap()
                    data?.tripMode?.let { 
                        _tripMode.value = it
                        sessionManager.saveTripMode(it)
                    }
                }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    fun refreshStatus() {
        if (vehicleId <= 0) return
        
        viewModelScope.launch {
            try {
                val response = apiService.getStatus(vehicleId, getTripDate(), getTripType())
                if (response.isSuccessful && response.body()?.status == 1) {
                    val body = response.body()
                    _statusMap.value = body?.statusMap ?: emptyMap()
                    body?.mode?.let {
                        _tripMode.value = it
                        sessionManager.saveTripMode(it)
                    }
                }
            } catch (e: Exception) {
                // Silent refresh failure
            }
        }
    }
    
    fun startAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            while (isActive) {
                delay(3000)
                refreshStatus()
            }
        }
    }
    
    fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }
    
    // TRIP MODE - Updates database via API
    fun toggleTripMode() {
        val currentMode = _tripMode.value ?: "pickup"
        val newMode = if (currentMode == "pickup") "drop" else "pickup"
        
        viewModelScope.launch {
            try {
                val response = apiService.setTripMode(
                    vehicleId,
                    getTripDate(),
                    getTripType(),
                    newMode
                )
                if (response.isSuccessful && response.body()?.status == 1) {
                    val mode = response.body()?.mode ?: newMode
                    _tripMode.value = mode
                    sessionManager.saveTripMode(mode)
                } else {
                    _error.value = response.body()?.message ?: "Failed to change mode"
                }
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
    
    // NFC CHECKIN
    fun checkin(uid: String, lat: Double?, lng: Double?, accuracy: Float?) {
        if (vehicleId <= 0) return
        
        viewModelScope.launch {
            try {
                val response = apiService.checkin(
                    vehicleId,
                    getTripDate(),
                    getTripType(),
                    uid,
                    lat,
                    lng,
                    accuracy
                )
                
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == 1) {
                        val isAlready = (body.already ?: 0) == 1
                        val studentName = body.student?.name ?: "Student"
                        val ssid = body.student?.studentSessionId?.toString()
                        
                        // Update local status
                        if (ssid != null && body.state != null) {
                            val newMap = _statusMap.value?.toMutableMap() ?: mutableMapOf()
                            newMap[ssid] = body.state
                            _statusMap.value = newMap
                        }
                        
                        _scanResult.value = ScanResult(
                            success = true,
                            isAlready = isAlready,
                            studentName = studentName,
                            message = body.message ?: "OK",
                            code = body.code
                        )
                    } else {
                        _scanResult.value = ScanResult(
                            success = false,
                            isAlready = false,
                            studentName = null,
                            message = body?.message ?: "Checkin failed",
                            code = body?.code
                        )
                    }
                }
            } catch (e: Exception) {
                _scanResult.value = ScanResult(
                    success = false,
                    isAlready = false,
                    studentName = null,
                    message = e.message ?: "Network error",
                    code = null
                )
            }
        }
    }
    
    // MANUAL STATUS - Updates database
    fun setManualStatus(studentSessionId: Int, target: String) {
        if (vehicleId <= 0) return
        
        viewModelScope.launch {
            try {
                val response = apiService.setManualStatus(
                    vehicleId,
                    getTripDate(),
                    getTripType(),
                    studentSessionId,
                    target
                )
                
                if (response.isSuccessful && response.body()?.status == 1) {
                    val body = response.body()
                    val ssid = studentSessionId.toString()
                    
                    // Update local status
                    if (body?.state != null) {
                        val newMap = _statusMap.value?.toMutableMap() ?: mutableMapOf()
                        newMap[ssid] = body.state
                        _statusMap.value = newMap
                    } else if (target == "missing") {
                        val newMap = _statusMap.value?.toMutableMap() ?: mutableMapOf()
                        newMap.remove(ssid)
                        _statusMap.value = newMap
                    }
                    
                    _scanResult.value = ScanResult(
                        success = true,
                        isAlready = false,
                        studentName = null,
                        message = body?.message ?: "Updated",
                        code = body?.code
                    )
                } else {
                    _error.value = response.body()?.message ?: "Failed"
                }
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
    
    // LOCATION UPDATE - Saves to database
    fun updateLocation(lat: Double, lng: Double, accuracy: Float?, heading: Float?, speed: Float?) {
        if (vehicleId <= 0) return
        
        viewModelScope.launch {
            try {
                apiService.updateLocation(vehicleId, lat, lng, accuracy, heading, speed)
                // Silent - no UI feedback needed
            } catch (e: Exception) {
                // Silent failure
            }
        }
    }
    
    fun clearScanResult() {
        _scanResult.value = null
    }
    
    fun clearError() {
        _error.value = null
    }
    
    fun logout() {
        viewModelScope.launch {
            try {
                apiService.logout()
            } catch (e: Exception) {
                // Ignore
            }
            sessionManager.clear()
            ApiClient.reset()
        }
    }
    
    data class ScanResult(
        val success: Boolean,
        val isAlready: Boolean,
        val studentName: String?,
        val message: String,
        val code: String?
    )
}
