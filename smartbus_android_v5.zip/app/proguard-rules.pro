-keepattributes Signature
-keepattributes *Annotation*
-keep class com.greenyouth.smartbus.data.** { *; }
-keep class retrofit2.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
