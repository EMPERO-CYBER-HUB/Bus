package com.greenyouth.smartbus.util

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.greenyouth.smartbus.data.Staff
import com.greenyouth.smartbus.data.Vehicle

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val PREFS_NAME = "smartbus_prefs"
        private const val KEY_TOKEN = "token"
        private const val KEY_STAFF = "staff"
        private const val KEY_VEHICLE = "vehicle"
        private const val KEY_TRIP_MODE = "trip_mode"
        private const val KEY_TRIP_TYPE = "trip_type"
        private const val KEY_TRIP_DATE = "trip_date"
        private const val KEY_GPS_ACTIVE = "gps_active"
        private const val KEY_LANGUAGE = "language"
    }

    fun saveToken(token: String) {
        prefs.edit().putString(KEY_TOKEN, token).apply()
    }

    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)

    fun saveStaff(staff: Staff) {
        prefs.edit().putString(KEY_STAFF, gson.toJson(staff)).apply()
    }

    fun getStaff(): Staff? {
        val json = prefs.getString(KEY_STAFF, null) ?: return null
        return try {
            gson.fromJson(json, Staff::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun saveVehicle(vehicle: Vehicle) {
        prefs.edit().putString(KEY_VEHICLE, gson.toJson(vehicle)).apply()
    }

    fun getVehicle(): Vehicle? {
        val json = prefs.getString(KEY_VEHICLE, null) ?: return null
        return try {
            gson.fromJson(json, Vehicle::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun saveTripMode(mode: String) {
        prefs.edit().putString(KEY_TRIP_MODE, mode).apply()
    }

    fun getTripMode(): String = prefs.getString(KEY_TRIP_MODE, "pickup") ?: "pickup"

    fun saveTripType(type: String) {
        prefs.edit().putString(KEY_TRIP_TYPE, type).apply()
    }

    fun getTripType(): String = prefs.getString(KEY_TRIP_TYPE, "morning") ?: "morning"

    fun saveTripDate(date: String) {
        prefs.edit().putString(KEY_TRIP_DATE, date).apply()
    }

    fun getTripDate(): String? = prefs.getString(KEY_TRIP_DATE, null)

    fun saveGpsActive(active: Boolean) {
        prefs.edit().putBoolean(KEY_GPS_ACTIVE, active).apply()
    }

    fun isGpsActive(): Boolean = prefs.getBoolean(KEY_GPS_ACTIVE, false)

    fun saveLanguage(lang: String) {
        prefs.edit().putString(KEY_LANGUAGE, lang).apply()
    }

    fun getLanguage(): String = prefs.getString(KEY_LANGUAGE, "en") ?: "en"

    fun isLoggedIn(): Boolean = !getToken().isNullOrEmpty() && getVehicle() != null

    fun clear() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_STAFF)
            .remove(KEY_VEHICLE)
            .remove(KEY_TRIP_MODE)
            .remove(KEY_GPS_ACTIVE)
            .apply()
    }
}
