package com.greenyouth.smartbus.ui.main

import android.Manifest
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.data.TripMode
import com.greenyouth.smartbus.data.TripType
import com.greenyouth.smartbus.databinding.ActivityMainBinding
import com.greenyouth.smartbus.service.LocationService
import com.greenyouth.smartbus.ui.login.LoginActivity
import com.greenyouth.smartbus.util.ImageUtils
import com.greenyouth.smartbus.util.LocaleHelper
import com.greenyouth.smartbus.util.NfcHelper
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var studentAdapter: StudentAdapter

    private var currentLat: Double? = null
    private var currentLng: Double? = null
    private var currentAccuracy: Float? = null

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true

        if (fineGranted || coarseGranted) {
            checkBackgroundLocationPermission()
        } else {
            Toast.makeText(this, R.string.location_permission_required, Toast.LENGTH_LONG).show()
        }
    }

    private val backgroundLocationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startLocationService()
        } else {
            Toast.makeText(this, R.string.background_location_required, Toast.LENGTH_LONG).show()
        }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        setupNfc()
        setupViews()
        observeViewModel()

        viewModel.loadRoster()
        updateCurrentLocation()
    }

    private fun setupNfc() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter != null) {
            pendingIntent = PendingIntent.getActivity(
                this, 0,
                Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_MUTABLE
            )
        }
    }

    private fun setupViews() {
        viewModel.getVehicle()?.let { vehicle ->
            binding.tvBusNumber.text = "Bus ${vehicle.vehicleNo}"
            binding.tvDriverInfo.text = "Driver: ${vehicle.driverName ?: "N/A"}"
            ImageUtils.loadBusImage(binding.ivBusPhoto, vehicle.photoUrl)
        }

        studentAdapter = StudentAdapter { ssid, target ->
            viewModel.setManualStatus(ssid, target)
        }
        binding.rvStudents.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = studentAdapter
        }

        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadRoster()
        }
        binding.swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent)

        binding.btnMenu.setOnClickListener { showMenu(it) }
        binding.cardDate.setOnClickListener { showDatePicker() }
        binding.cardTripType.setOnClickListener { showTripTypeDialog() }
        binding.btnTripMode.setOnClickListener { viewModel.toggleTripMode() }
        binding.btnGpsToggle.setOnClickListener { toggleGps() }

        binding.fabNfc.setOnClickListener {
            if (nfcAdapter == null) {
                Toast.makeText(this, "NFC not available", Toast.LENGTH_SHORT).show()
            } else if (!nfcAdapter!!.isEnabled) {
                Toast.makeText(this, "Please enable NFC", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.nfc_ready), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(this) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.swipeRefresh.isRefreshing = false
        }

        viewModel.students.observe(this) { students ->
            studentAdapter.submitList(students)
            binding.emptyState.visibility = if (students.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.stats.observe(this) { stats ->
            binding.tvTotalCount.text = stats.total.toString()
            binding.tvOnBusCount.text = stats.onBus.toString()
            binding.tvDroppedCount.text = stats.dropped.toString()
            binding.tvMissingCount.text = stats.missing.toString()
        }

        viewModel.tripMode.observe(this) { mode ->
            studentAdapter.tripMode = mode
            when (mode) {
                TripMode.PICKUP -> {
                    binding.btnTripMode.text = getString(R.string.pickup_mode)
                    binding.btnTripMode.setBackgroundColor(ContextCompat.getColor(this, R.color.status_on_bus))
                }
                TripMode.DROP -> {
                    binding.btnTripMode.text = getString(R.string.drop_mode)
                    binding.btnTripMode.setBackgroundColor(ContextCompat.getColor(this, R.color.status_dropped))
                }
            }
        }

        viewModel.tripType.observe(this) { type ->
            binding.tvTripType.text = when (type) {
                TripType.MORNING -> getString(R.string.morning)
                TripType.AFTERNOON -> getString(R.string.afternoon)
            }
        }

        viewModel.tripDate.observe(this) { date ->
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            binding.tvDate.text = if (date == today) getString(R.string.today) else formatDisplayDate(date)
        }

        viewModel.isGpsActive.observe(this) { active ->
            if (active) {
                binding.btnGpsToggle.text = getString(R.string.stop_trip)
                binding.btnGpsToggle.setIconResource(R.drawable.ic_stop)
                binding.ivGpsIndicator.visibility = View.VISIBLE
                binding.tvGpsStatus.visibility = View.VISIBLE
                binding.tvGpsStatus.text = getString(R.string.sharing_location)
            } else {
                binding.btnGpsToggle.text = getString(R.string.start_trip)
                binding.btnGpsToggle.setIconResource(R.drawable.ic_play)
                binding.ivGpsIndicator.visibility = View.GONE
                binding.tvGpsStatus.visibility = View.GONE
            }
        }

        viewModel.message.observe(this) { msg -> msg?.let { showMessageDialog(it) } }
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor, Gravity.END)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)

        val currentLang = LocaleHelper.getLanguageDisplayName(LocaleHelper.getLanguage(this))
        popup.menu.findItem(R.id.menu_language)?.title = "${getString(R.string.language)}: $currentLang"

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_language -> { showLanguageDialog(); true }
                R.id.menu_logout -> { showLogoutConfirmation(); true }
                else -> false
            }
        }

        try {
            val menuHelper = popup.javaClass.getDeclaredField("mPopup")
            menuHelper.isAccessible = true
            val menuPopupHelper = menuHelper.get(popup)
            val showMethod = menuPopupHelper.javaClass.getDeclaredMethod("show")
            showMethod.invoke(menuPopupHelper)
            
            val listPopup = menuPopupHelper.javaClass.getDeclaredField("mPopup")
            listPopup.isAccessible = true
            val listPopupWindow = listPopup.get(menuPopupHelper)
            val listView = listPopupWindow.javaClass.getDeclaredMethod("getListView").invoke(listPopupWindow)
            
            if (listView is android.widget.ListView) {
                val headerView = LayoutInflater.from(this).inflate(R.layout.layout_menu_header, null)
                viewModel.getStaff()?.let { staff ->
                    headerView.findViewById<TextView>(R.id.tvCoordinatorName).text = staff.name
                    headerView.findViewById<TextView>(R.id.tvCoordinatorRole).text = staff.roleName ?: getString(R.string.coordinator)
                    ImageUtils.loadStaffImage(headerView.findViewById(R.id.ivCoordinatorPhoto), staff.photoUrl)
                }
                listView.addHeaderView(headerView, null, false)
            }
        } catch (e: Exception) {
            popup.show()
        }
    }

    private fun showLanguageDialog() {
        val languages = LocaleHelper.getAvailableLanguages()
        val currentLang = LocaleHelper.getLanguage(this)
        val names = languages.map { it.second }.toTypedArray()
        val currentIndex = languages.indexOfFirst { it.first == currentLang }.coerceAtLeast(0)

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.select_language)
            .setSingleChoiceItems(names, currentIndex) { dialog, which ->
                val selectedLang = languages[which].first
                if (selectedLang != currentLang) {
                    LocaleHelper.setLocale(this, selectedLang)
                    recreate()
                }
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showLogoutConfirmation() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.logout)
            .setMessage(R.string.confirm_logout)
            .setPositiveButton(R.string.yes) { _, _ ->
                stopLocationService()
                viewModel.logout()
                startActivity(Intent(this, LoginActivity::class.java))
                finishAffinity()
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private fun showDatePicker() {
        val currentDate = viewModel.tripDate.value ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val parts = currentDate.split("-")
        DatePickerDialog(this, { _, y, m, d ->
            viewModel.setTripDate(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d))
        }, parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt()).show()
    }

    private fun showTripTypeDialog() {
        val types = arrayOf(getString(R.string.morning), getString(R.string.afternoon))
        val currentIndex = if (viewModel.tripType.value == TripType.MORNING) 0 else 1

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.trip_type)
            .setSingleChoiceItems(types, currentIndex) { dialog, which ->
                viewModel.setTripType(if (which == 0) TripType.MORNING else TripType.AFTERNOON)
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showMessageDialog(message: MainViewModel.Message) {
        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(message.title)
            .setPositiveButton("OK") { _, _ -> viewModel.clearMessage() }

        when (message.type) {
            MainViewModel.MessageType.WRONG_BUS -> {
                builder.setMessage(buildString {
                    append(message.studentName ?: "Student")
                    append(" is assigned to:\n\n")
                    append("🚌 Bus: ${message.assignedBus ?: "Unknown"}\n")
                    append("📍 Route: ${message.assignedRoute ?: "Unknown"}\n\n")
                    append("Please direct them to their correct bus.")
                })
            }
            else -> builder.setMessage(message.text)
        }
        builder.show()
    }

    private fun toggleGps() {
        if (viewModel.isGpsActive.value == true) {
            stopLocationService()
            viewModel.setGpsActive(false)
            Toast.makeText(this, R.string.gps_stopped, Toast.LENGTH_SHORT).show()
        } else {
            requestLocationPermissions()
        }
    }

    private fun requestLocationPermissions() {
        val permissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            checkBackgroundLocationPermission()
        } else {
            locationPermissionLauncher.launch(permissions)
        }
    }

    private fun checkBackgroundLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startLocationService()
            } else {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Background Location")
                    .setMessage("To track location when app is closed, please allow 'All the time' location access.")
                    .setPositiveButton("Allow") { _, _ -> backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        } else {
            startLocationService()
        }
    }

    private fun startLocationService() {
        val intent = Intent(this, LocationService::class.java).apply { action = LocationService.ACTION_START }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        viewModel.setGpsActive(true)
        Toast.makeText(this, R.string.gps_started, Toast.LENGTH_SHORT).show()
    }

    private fun stopLocationService() {
        startService(Intent(this, LocationService::class.java).apply { action = LocationService.ACTION_STOP })
    }

    private fun updateCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                location?.let { currentLat = it.latitude; currentLng = it.longitude; currentAccuracy = it.accuracy }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, null, null)
        updateCurrentLocation()
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action || NfcAdapter.ACTION_TECH_DISCOVERED == intent.action) {
            NfcHelper.getTagUid(intent)?.let { viewModel.processNfcCard(it, currentLat, currentLng, currentAccuracy) }
                ?: Toast.makeText(this, "Failed to read NFC card", Toast.LENGTH_SHORT).show()
        }
    }

    private fun formatDisplayDate(date: String): String = try {
        SimpleDateFormat("MMM d", Locale.US).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!)
    } catch (e: Exception) { date }
}
