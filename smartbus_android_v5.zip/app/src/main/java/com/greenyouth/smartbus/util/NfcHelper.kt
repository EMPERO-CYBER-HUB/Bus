package com.greenyouth.smartbus.util

import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag

object NfcHelper {

    fun getTagUid(intent: Intent): String? {
        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG) ?: return null
        return bytesToHex(tag.id)
    }

    fun getTagUid(tag: Tag?): String? {
        if (tag == null) return null
        return bytesToHex(tag.id)
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02X", b))
        }
        return sb.toString()
    }
}
