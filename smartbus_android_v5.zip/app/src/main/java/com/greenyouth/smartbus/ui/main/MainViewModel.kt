package com.greenyouth.smartbus.ui.main

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.*
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }

    private val api = ApiClient.build(application)
    private val sessionManager = SessionManager(application)

    // State
    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _students = MutableLiveData<List<StudentListItem>>(emptyList())
    val students: LiveData<List<StudentListItem>> = _students

    private val _tripMode = MutableLiveData(TripMode.PICKUP)
    val tripMode: LiveData<TripMode> = _tripMode

    private val _tripType = MutableLiveData(TripType.MORNING)
    val tripType: LiveData<TripType> = _tripType

    private val _tripDate = MutableLiveData(getTodayDate())
    val tripDate: LiveData<String> = _tripDate

    private val _stats = MutableLiveData(Stats(0, 0, 0, 0))
    val stats: LiveData<Stats> = _stats

    private val _message = MutableLiveData<Message?>()
    val message: LiveData<Message?> = _message

    private val _isGpsActive = MutableLiveData(false)
    val isGpsActive: LiveData<Boolean> = _isGpsActive

    data class Stats(val total: Int, val onBus: Int, val dropped: Int, val missing: Int)

    data class Message(
        val type: MessageType,
        val title: String,
        val text: String,
        val studentName: String? = null,
        val assignedBus: String? = null,
        val assignedRoute: String? = null
    )

    enum class MessageType { SUCCESS, ERROR, WARNING, WRONG_BUS }

    // Initialization
    init {
        // Auto-detect trip type based on time
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        _tripType.value = if (hour < 14) TripType.MORNING else TripType.AFTERNOON
        
        // Load saved values
        sessionManager.getTripDate()?.let { _tripDate.value = it }
        _tripMode.value = if (sessionManager.getTripMode() == "drop") TripMode.DROP else TripMode.PICKUP
        _isGpsActive.value = sessionManager.isGpsActive()
    }

    fun getVehicle(): Vehicle? = sessionManager.getVehicle()
    fun getStaff(): Staff? = sessionManager.getStaff()

    private fun getTodayDate(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    fun setTripDate(date: String) {
        _tripDate.value = date
        sessionManager.saveTripDate(date)
        loadRoster()
    }

    fun setTripType(type: TripType) {
        _tripType.value = type
        sessionManager.saveTripType(type.value)
        loadRoster()
    }

    fun toggleTripMode() {
        val vehicleId = sessionManager.getVehicle()?.id ?: return
        val newMode = if (_tripMode.value == TripMode.PICKUP) TripMode.DROP else TripMode.PICKUP

        viewModelScope.launch {
            try {
                val response = api.setTripMode(
                    vehicleId = vehicleId,
                    tripDate = _tripDate.value ?: getTodayDate(),
                    tripType = _tripType.value?.value ?: "morning",
                    mode = newMode.value
                )

                if (response.isSuccessful && response.body()?.status == 1) {
                    _tripMode.postValue(newMode)
                    sessionManager.saveTripMode(newMode.value)
                    Log.d(TAG, "Trip mode changed to ${newMode.value}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error setting trip mode", e)
            }
        }
    }

    fun loadRoster() {
        val vehicleId = sessionManager.getVehicle()?.id ?: return

        _isLoading.value = true

        viewModelScope.launch {
            try {
                val response = api.getRoster(
                    vehicleId = vehicleId,
                    tripDate = _tripDate.value ?: getTodayDate(),
                    tripType = _tripType.value?.value ?: "morning"
                )

                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == 1 && body.data != null) {
                        val data = body.data
                        val statusMap = data.statusMap ?: emptyMap()
                        
                        // Update trip mode from server
                        data.tripMode?.let { mode ->
                            _tripMode.postValue(
                                if (mode == "drop") TripMode.DROP else TripMode.PICKUP
                            )
                            sessionManager.saveTripMode(mode)
                        }

                        // Map students with status
                        val items = data.students.map { student ->
                            val status = statusMap[student.studentSessionId.toString()]
                            val listItem = StudentListItem(student)
                            
                            if (status != null) {
                                listItem.boardedAt = status.boardedAt
                                listItem.droppedAt = status.droppedAt
                                
                                listItem.currentStatus = when {
                                    !status.droppedAt.isNullOrBlank() -> StudentStatusType.DROPPED
                                    !status.boardedAt.isNullOrBlank() -> StudentStatusType.ON_BUS
                                    else -> StudentStatusType.MISSING
                                }
                            }
                            
                            listItem
                        }

                        _students.postValue(items)
                        updateStats(items)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading roster", e)
                _message.postValue(Message(MessageType.ERROR, "Error", e.message ?: "Failed to load students"))
            } finally {
                _isLoading.postValue(false)
            }
        }
    }

    fun refreshStatus() {
        val vehicleId = sessionManager.getVehicle()?.id ?: return

        viewModelScope.launch {
            try {
                val response = api.getStatus(
                    vehicleId = vehicleId,
                    tripDate = _tripDate.value ?: getTodayDate(),
                    tripType = _tripType.value?.value ?: "morning"
                )

                if (response.isSuccessful && response.body()?.status == 1) {
                    val statusMap = response.body()?.statusMap ?: return@launch
                    
                    val currentList = _students.value?.toMutableList() ?: return@launch
                    
                    currentList.forEachIndexed { index, item ->
                        val status = statusMap[item.student.studentSessionId.toString()]
                        if (status != null) {
                            currentList[index] = item.copy(
                                boardedAt = status.boardedAt,
                                droppedAt = status.droppedAt,
                                currentStatus = when {
                                    !status.droppedAt.isNullOrBlank() -> StudentStatusType.DROPPED
                                    !status.boardedAt.isNullOrBlank() -> StudentStatusType.ON_BUS
                                    else -> StudentStatusType.MISSING
                                }
                            )
                        }
                    }
                    
                    _students.postValue(currentList)
                    updateStats(currentList)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error refreshing status", e)
            }
        }
    }

    fun processNfcCard(uid: String, lat: Double?, lng: Double?, accuracy: Float?) {
        val vehicleId = sessionManager.getVehicle()?.id ?: return

        viewModelScope.launch {
            try {
                val response = api.checkin(
                    vehicleId = vehicleId,
                    tripDate = _tripDate.value ?: getTodayDate(),
                    tripType = _tripType.value?.value ?: "morning",
                    uid = uid,
                    lat = lat,
                    lng = lng,
                    accuracy = accuracy
                )

                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) {
                        handleCheckinResponse(body)
                    }
                } else {
                    _message.postValue(Message(MessageType.ERROR, "Error", "Check-in failed"))
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing NFC", e)
                _message.postValue(Message(MessageType.ERROR, "Error", e.message ?: "Check-in failed"))
            }
        }
    }

    private fun handleCheckinResponse(response: CheckinResponse) {
        val studentName = response.student?.name ?: "Student"

        when (response.code) {
            "UID_NOT_REGISTERED" -> {
                _message.postValue(Message(
                    MessageType.ERROR,
                    "Card Not Registered",
                    "This card is not registered in the system"
                ))
            }
            "WRONG_BUS" -> {
                _message.postValue(Message(
                    MessageType.WRONG_BUS,
                    "Wrong Bus!",
                    "$studentName is assigned to a different bus",
                    studentName = studentName,
                    assignedBus = response.assignedVehicleNo,
                    assignedRoute = response.assignedRoute
                ))
            }
            "ALREADY_ONBUS" -> {
                _message.postValue(Message(
                    MessageType.WARNING,
                    "Already On Bus",
                    "$studentName is already on the bus"
                ))
            }
            "ALREADY_DROPPED" -> {
                _message.postValue(Message(
                    MessageType.WARNING,
                    "Already Dropped",
                    "$studentName has already been dropped"
                ))
            }
            "PICKUP_OK", "BOARD_OK" -> {
                _message.postValue(Message(
                    MessageType.SUCCESS,
                    "Boarded! ✓",
                    "$studentName boarded successfully"
                ))
                refreshStatus()
            }
            "DROP_OK" -> {
                _message.postValue(Message(
                    MessageType.SUCCESS,
                    "Dropped! ✓",
                    "$studentName dropped successfully"
                ))
                refreshStatus()
            }
            else -> {
                if (response.status == 1) {
                    _message.postValue(Message(
                        MessageType.SUCCESS,
                        "Success",
                        response.message ?: "Check-in recorded"
                    ))
                    refreshStatus()
                } else {
                    _message.postValue(Message(
                        MessageType.ERROR,
                        "Error",
                        response.message ?: "Check-in failed"
                    ))
                }
            }
        }
    }

    fun setManualStatus(studentSessionId: Int, target: String) {
        val vehicleId = sessionManager.getVehicle()?.id ?: return

        viewModelScope.launch {
            try {
                val response = api.setManualStatus(
                    vehicleId = vehicleId,
                    tripDate = _tripDate.value ?: getTodayDate(),
                    tripType = _tripType.value?.value ?: "morning",
                    studentSessionId = studentSessionId,
                    target = target
                )

                if (response.isSuccessful && response.body()?.status == 1) {
                    val body = response.body()!!
                    val studentName = body.student?.name ?: "Student"
                    
                    _message.postValue(Message(
                        MessageType.SUCCESS,
                        when (target) {
                            "board" -> "Boarded"
                            "drop" -> "Dropped"
                            else -> "Updated"
                        },
                        when (target) {
                            "board" -> "$studentName marked as on bus"
                            "drop" -> "$studentName marked as dropped"
                            else -> "$studentName marked as missing"
                        }
                    ))
                    
                    refreshStatus()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error setting manual status", e)
                _message.postValue(Message(MessageType.ERROR, "Error", e.message ?: "Failed"))
            }
        }
    }

    fun setGpsActive(active: Boolean) {
        _isGpsActive.value = active
        sessionManager.saveGpsActive(active)
    }

    fun logout() {
        viewModelScope.launch {
            try {
                api.logout()
            } catch (e: Exception) {
                // Ignore logout errors
            }
        }
        sessionManager.clear()
    }

    fun clearMessage() {
        _message.value = null
    }

    private fun updateStats(items: List<StudentListItem>) {
        val total = items.size
        val onBus = items.count { it.currentStatus == StudentStatusType.ON_BUS }
        val dropped = items.count { it.currentStatus == StudentStatusType.DROPPED }
        val missing = items.count { it.currentStatus == StudentStatusType.MISSING }
        _stats.postValue(Stats(total, onBus, dropped, missing))
    }
}
