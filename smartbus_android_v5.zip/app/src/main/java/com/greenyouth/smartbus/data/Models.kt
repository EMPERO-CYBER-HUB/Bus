package com.greenyouth.smartbus.data

import com.google.gson.annotations.SerializedName

// Auth
data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val status: Int,
    val message: String,
    val data: LoginData?
)

data class LoginData(
    val token: String,
    @SerializedName("expires_at") val expiresAt: String?,
    val staff: Staff?,
    @SerializedName("assigned_vehicle") val assignedVehicle: Vehicle?,
    @SerializedName("is_coordinator") val isCoordinator: Boolean
)

data class Staff(
    val id: Int,
    @SerializedName("employee_id") val employeeId: String?,
    val name: String,
    val email: String,
    @SerializedName("contact_no") val contactNo: String?,
    @SerializedName("role_id") val roleId: Int?,
    @SerializedName("role_name") val roleName: String?,
    @SerializedName("photo_url") val photoUrl: String?
)

data class Vehicle(
    val id: Int,
    @SerializedName("vehicle_no") val vehicleNo: String,
    @SerializedName("vehicle_model") val vehicleModel: String?,
    @SerializedName("driver_name") val driverName: String?,
    @SerializedName("driver_contact") val driverContact: String?,
    @SerializedName("photo_url") val photoUrl: String?
)

// Roster
data class RosterResponse(
    val status: Int,
    val message: String?,
    val data: RosterData?
)

data class RosterData(
    val students: List<Student>,
    @SerializedName("status_map") val statusMap: Map<String, StudentStatus>?,
    @SerializedName("trip_mode") val tripMode: String?,
    @SerializedName("trip_date") val tripDate: String?,
    @SerializedName("trip_type") val tripType: String?
)

data class Student(
    @SerializedName("student_session_id") val studentSessionId: Int,
    @SerializedName("student_id") val studentId: Int?,
    val firstname: String?,
    val middlename: String?,
    val lastname: String?,
    @SerializedName("class_name") val className: String?,
    @SerializedName("section_name") val sectionName: String?,
    @SerializedName("guardian_relation") val guardianRelation: String?,
    @SerializedName("guardian_name") val guardianName: String?,
    @SerializedName("guardian_phone") val guardianPhone: String?,
    @SerializedName("pickup_point") val pickupPoint: String?,
    val image: String?,
    @SerializedName("photo_url") val photoUrl: String?,
    @SerializedName("card_uid") val cardUid: String?,
    // For wrong bus detection
    @SerializedName("assigned_vehicle_no") val assignedVehicleNo: String?,
    @SerializedName("assigned_route") val assignedRoute: String?
) {
    val fullName: String
        get() = listOfNotNull(firstname, middlename, lastname)
            .filter { it.isNotBlank() }
            .joinToString(" ")

    val classSection: String
        get() {
            val c = className ?: ""
            val s = sectionName ?: ""
            return if (s.isNotBlank()) "$c ($s)" else c
        }

    val guardianInfo: String
        get() {
            val rel = guardianRelation?.uppercase() ?: ""
            val name = guardianName ?: ""
            return if (rel.isNotBlank() && name.isNotBlank()) "$rel - $name"
            else name.ifBlank { rel }
        }
}

data class StudentStatus(
    @SerializedName("checked_in_at") val checkedInAt: String?,
    @SerializedName("boarded_at") val boardedAt: String?,
    @SerializedName("dropped_at") val droppedAt: String?
)

// Checkin Response
data class CheckinResponse(
    val status: Int,
    val message: String?,
    val code: String?,
    val already: Int?,
    @SerializedName("trip_mode") val tripMode: String?,
    val student: CheckinStudent?,
    val state: StudentStatus?,
    // Wrong bus info
    @SerializedName("wrong_bus") val wrongBus: Boolean?,
    @SerializedName("assigned_vehicle_no") val assignedVehicleNo: String?,
    @SerializedName("assigned_route") val assignedRoute: String?
)

data class CheckinStudent(
    @SerializedName("student_session_id") val studentSessionId: Int,
    val name: String?
)

// Trip Mode
data class TripModeResponse(
    val status: Int,
    val message: String?,
    val mode: String?
)

// Location
data class LocationResponse(
    val status: Int,
    val message: String?,
    val data: LocationData?
)

data class LocationData(
    @SerializedName("vehicle_id") val vehicleId: Int?,
    val lat: Double?,
    val lng: Double?,
    val accuracy: Float?,
    val heading: Float?,
    val speed: Float?,
    @SerializedName("updated_at") val updatedAt: String?
)

// Status Response
data class StatusResponse(
    val status: Int,
    val message: String?,
    @SerializedName("status_map") val statusMap: Map<String, StudentStatus>?,
    val mode: String?
)

// Generic Response
data class GenericResponse(
    val status: Int,
    val message: String?
)

// UI State
data class StudentListItem(
    val student: Student,
    var currentStatus: StudentStatusType = StudentStatusType.MISSING,
    var boardedAt: String? = null,
    var droppedAt: String? = null
)

enum class StudentStatusType {
    MISSING, ON_BUS, DROPPED
}

enum class TripMode(val value: String) {
    PICKUP("pickup"),
    DROP("drop")
}

enum class TripType(val value: String) {
    MORNING("morning"),
    AFTERNOON("afternoon")
}
