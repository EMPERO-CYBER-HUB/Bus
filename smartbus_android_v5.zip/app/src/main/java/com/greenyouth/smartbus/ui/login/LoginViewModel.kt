package com.greenyouth.smartbus.ui.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.data.LoginRequest
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val api = ApiClient.build(application)
    private val sessionManager = SessionManager(application)

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _loginResult = MutableLiveData<LoginResult>()
    val loginResult: LiveData<LoginResult> = _loginResult

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _loginResult.value = LoginResult.Error("Email and password required")
            return
        }

        _isLoading.value = true

        viewModelScope.launch {
            try {
                val response = api.login(LoginRequest(email.trim(), password))

                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == 1 && body.data != null) {
                        val data = body.data
                        
                        // Save session
                        sessionManager.saveToken(data.token)
                        data.staff?.let { sessionManager.saveStaff(it) }
                        
                        // Check if coordinator
                        if (data.assignedVehicle != null) {
                            sessionManager.saveVehicle(data.assignedVehicle)
                            _loginResult.postValue(LoginResult.Success)
                        } else {
                            sessionManager.clear()
                            _loginResult.postValue(LoginResult.NotCoordinator)
                        }
                    } else {
                        _loginResult.postValue(LoginResult.Error(body?.message ?: "Login failed"))
                    }
                } else {
                    _loginResult.postValue(LoginResult.Error("Invalid credentials"))
                }
            } catch (e: Exception) {
                _loginResult.postValue(LoginResult.Error(e.message ?: "Network error"))
            } finally {
                _isLoading.postValue(false)
            }
        }
    }

    sealed class LoginResult {
        object Success : LoginResult()
        object NotCoordinator : LoginResult()
        data class Error(val message: String) : LoginResult()
    }
}
