package com.greenyouth.smartbus.api

import com.greenyouth.smartbus.data.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // Auth
    @POST("bus_api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("bus_api/auth/logout")
    suspend fun logout(): Response<GenericResponse>

    @GET("bus_api/auth/me")
    suspend fun me(): Response<LoginResponse>

    // Roster
    @GET("bus_api/smartbus/roster")
    suspend fun getRoster(
        @Query("vehicle_id") vehicleId: Int,
        @Query("trip_date") tripDate: String,
        @Query("trip_type") tripType: String
    ): Response<RosterResponse>

    // Status only (lightweight)
    @GET("bus_api/smartbus/status")
    suspend fun getStatus(
        @Query("vehicle_id") vehicleId: Int,
        @Query("trip_date") tripDate: String,
        @Query("trip_type") tripType: String
    ): Response<StatusResponse>

    // Trip Mode
    @GET("bus_api/smartbus/trip_mode")
    suspend fun getTripMode(
        @Query("vehicle_id") vehicleId: Int,
        @Query("trip_date") tripDate: String,
        @Query("trip_type") tripType: String
    ): Response<TripModeResponse>

    @FormUrlEncoded
    @POST("bus_api/smartbus/trip_mode")
    suspend fun setTripMode(
        @Field("vehicle_id") vehicleId: Int,
        @Field("trip_date") tripDate: String,
        @Field("trip_type") tripType: String,
        @Field("mode") mode: String
    ): Response<TripModeResponse>

    // NFC Checkin
    @FormUrlEncoded
    @POST("bus_api/smartbus/checkin")
    suspend fun checkin(
        @Field("vehicle_id") vehicleId: Int,
        @Field("trip_date") tripDate: String,
        @Field("trip_type") tripType: String,
        @Field("uid") uid: String,
        @Field("lat") lat: Double?,
        @Field("lng") lng: Double?,
        @Field("accuracy") accuracy: Float?
    ): Response<CheckinResponse>

    // Manual Status
    @FormUrlEncoded
    @POST("bus_api/smartbus/manual_status")
    suspend fun setManualStatus(
        @Field("vehicle_id") vehicleId: Int,
        @Field("trip_date") tripDate: String,
        @Field("trip_type") tripType: String,
        @Field("student_session_id") studentSessionId: Int,
        @Field("target") target: String
    ): Response<CheckinResponse>

    // Location
    @GET("bus_api/smartbus/location")
    suspend fun getLocation(
        @Query("vehicle_id") vehicleId: Int
    ): Response<LocationResponse>

    @FormUrlEncoded
    @POST("bus_api/smartbus/location")
    suspend fun updateLocation(
        @Field("vehicle_id") vehicleId: Int,
        @Field("lat") lat: Double,
        @Field("lng") lng: Double,
        @Field("accuracy") accuracy: Float?,
        @Field("heading") heading: Float?,
        @Field("speed") speed: Float?
    ): Response<LocationResponse>
}
