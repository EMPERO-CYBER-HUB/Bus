package com.greenyouth.smartbus.util

import android.widget.ImageView
import coil.load
import coil.request.CachePolicy
import coil.transform.CircleCropTransformation
import com.greenyouth.smartbus.R

object ImageUtils {

    /**
     * Fixes image URLs from API that incorrectly include /bus_api/ in the path.
     * API returns: https://greenyouthacademy.com/bus_api/uploads/...
     * Correct URL: https://greenyouthacademy.com/uploads/...
     */
    fun fixImageUrl(url: String?): String? {
        if (url.isNullOrBlank()) return null
        
        // Fix the bus_api path issue
        return url.replace("/bus_api/uploads/", "/uploads/")
            .replace("/bus_api/Uploads/", "/uploads/")
    }

    /**
     * Load image with caching and circle crop
     */
    fun loadCircleImage(imageView: ImageView, url: String?, placeholder: Int = R.drawable.ic_person) {
        val fixedUrl = fixImageUrl(url)
        
        if (fixedUrl.isNullOrBlank()) {
            imageView.setImageResource(placeholder)
            return
        }

        imageView.load(fixedUrl) {
            crossfade(true)
            placeholder(placeholder)
            error(placeholder)
            memoryCachePolicy(CachePolicy.ENABLED)
            diskCachePolicy(CachePolicy.ENABLED)
            transformations(CircleCropTransformation())
        }
    }

    /**
     * Load image with caching (no circle crop)
     */
    fun loadImage(imageView: ImageView, url: String?, placeholder: Int = R.drawable.ic_person) {
        val fixedUrl = fixImageUrl(url)
        
        if (fixedUrl.isNullOrBlank()) {
            imageView.setImageResource(placeholder)
            return
        }

        imageView.load(fixedUrl) {
            crossfade(true)
            placeholder(placeholder)
            error(placeholder)
            memoryCachePolicy(CachePolicy.ENABLED)
            diskCachePolicy(CachePolicy.ENABLED)
        }
    }

    /**
     * Load bus image
     */
    fun loadBusImage(imageView: ImageView, url: String?) {
        loadCircleImage(imageView, url, R.drawable.ic_bus_large)
    }

    /**
     * Load staff/coordinator image
     */
    fun loadStaffImage(imageView: ImageView, url: String?) {
        loadCircleImage(imageView, url, R.drawable.ic_person)
    }
}
