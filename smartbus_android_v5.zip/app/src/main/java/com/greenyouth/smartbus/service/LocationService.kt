package com.greenyouth.smartbus.service

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.SmartBusApp
import com.greenyouth.smartbus.api.ApiClient
import com.greenyouth.smartbus.ui.main.MainActivity
import com.greenyouth.smartbus.util.SessionManager
import kotlinx.coroutines.*

class LocationService : Service() {

    companion object {
        private const val TAG = "LocationService"
        const val ACTION_START = "com.greenyouth.smartbus.START_LOCATION"
        const val ACTION_STOP = "com.greenyouth.smartbus.STOP_LOCATION"
        private const val UPDATE_INTERVAL = 10000L // 10 seconds
        private const val FASTEST_INTERVAL = 5000L // 5 seconds
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var sessionManager: SessionManager
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var vehicleId: Int = 0
    private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        sessionManager = SessionManager(this)
        
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { location ->
                    sendLocationToServer(
                        lat = location.latitude,
                        lng = location.longitude,
                        accuracy = location.accuracy,
                        heading = if (location.hasBearing()) location.bearing else null,
                        speed = if (location.hasSpeed()) location.speed else null
                    )
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startLocationUpdates()
            ACTION_STOP -> stopLocationUpdates()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startLocationUpdates() {
        if (isRunning) return

        vehicleId = sessionManager.getVehicle()?.id ?: 0
        if (vehicleId == 0) {
            stopSelf()
            return
        }

        val notification = createNotification()
        startForeground(SmartBusApp.NOTIFICATION_ID_LOCATION, notification)

        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, UPDATE_INTERVAL)
            .setMinUpdateIntervalMillis(FASTEST_INTERVAL)
            .setWaitForAccurateLocation(false)
            .build()

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) 
            == PackageManager.PERMISSION_GRANTED) {
            
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
            
            isRunning = true
            sessionManager.saveGpsActive(true)
            Log.d(TAG, "Location updates started for vehicle $vehicleId")
        } else {
            Log.e(TAG, "Location permission not granted")
            stopSelf()
        }
    }

    private fun stopLocationUpdates() {
        if (!isRunning) return

        fusedLocationClient.removeLocationUpdates(locationCallback)
        sessionManager.saveGpsActive(false)
        isRunning = false
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        
        Log.d(TAG, "Location updates stopped")
    }

    private fun sendLocationToServer(
        lat: Double,
        lng: Double,
        accuracy: Float?,
        heading: Float?,
        speed: Float?
    ) {
        if (vehicleId == 0) return

        serviceScope.launch {
            try {
                val api = ApiClient.build(this@LocationService)
                val response = api.updateLocation(
                    vehicleId = vehicleId,
                    lat = lat,
                    lng = lng,
                    accuracy = accuracy,
                    heading = heading,
                    speed = speed
                )

                if (response.isSuccessful) {
                    Log.d(TAG, "Location sent: $lat, $lng")
                } else {
                    Log.e(TAG, "Failed to send location: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending location", e)
            }
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, SmartBusApp.CHANNEL_LOCATION)
            .setContentTitle(getString(R.string.location_tracking))
            .setContentText(getString(R.string.sharing_location))
            .setSmallIcon(R.drawable.ic_location)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (isRunning) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
            sessionManager.saveGpsActive(false)
        }
    }
}
