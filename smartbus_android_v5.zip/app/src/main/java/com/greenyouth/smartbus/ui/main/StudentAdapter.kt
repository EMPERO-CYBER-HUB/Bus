package com.greenyouth.smartbus.ui.main

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.greenyouth.smartbus.R
import com.greenyouth.smartbus.data.StudentListItem
import com.greenyouth.smartbus.data.StudentStatusType
import com.greenyouth.smartbus.data.TripMode
import com.greenyouth.smartbus.databinding.ItemStudentBinding
import java.text.SimpleDateFormat
import java.util.*

class StudentAdapter(
    private val onManualStatus: (Int, String) -> Unit
) : ListAdapter<StudentListItem, StudentAdapter.ViewHolder>(DiffCallback()) {

    var tripMode: TripMode = TripMode.PICKUP
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemStudentBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemStudentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: StudentListItem) {
            val context = binding.root.context
            val student = item.student

            // Name
            binding.tvStudentName.text = student.fullName

            // Class & Pickup Point
            binding.tvClass.text = student.classSection
            binding.tvPickupPoint.text = student.pickupPoint ?: ""

            // Guardian
            binding.tvGuardian.text = student.guardianInfo

            // Phone (clickable)
            val phone = student.guardianPhone
            if (!phone.isNullOrBlank()) {
                binding.layoutPhone.visibility = View.VISIBLE
                binding.tvPhone.text = phone
                binding.layoutPhone.setOnClickListener {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:$phone")
                    }
                    context.startActivity(intent)
                }
            } else {
                binding.layoutPhone.visibility = View.GONE
            }

            // Status badge
            updateStatusBadge(item.currentStatus)

            // Time info - only show for non-missing students
            if (item.currentStatus != StudentStatusType.MISSING) {
                binding.layoutTimes.visibility = View.VISIBLE
                
                val boardedTime = formatTime(item.boardedAt)
                val droppedTime = formatTime(item.droppedAt)
                
                binding.tvBoardedTime.text = if (boardedTime != null) "Boarded: $boardedTime" else ""
                binding.tvBoardedTime.visibility = if (boardedTime != null) View.VISIBLE else View.GONE
                
                binding.tvDroppedTime.text = if (droppedTime != null) "Dropped: $droppedTime" else ""
                binding.tvDroppedTime.visibility = if (droppedTime != null) View.VISIBLE else View.GONE
            } else {
                binding.layoutTimes.visibility = View.GONE
            }

            // Action buttons based on trip mode and current status
            setupActionButtons(item)
        }

        private fun updateStatusBadge(status: StudentStatusType) {
            val context = binding.root.context
            
            when (status) {
                StudentStatusType.ON_BUS -> {
                    binding.tvStatus.text = context.getString(R.string.on_bus)
                    binding.tvStatus.setBackgroundResource(R.drawable.bg_status_on_bus)
                    binding.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_on_bus))
                }
                StudentStatusType.DROPPED -> {
                    binding.tvStatus.text = context.getString(R.string.dropped)
                    binding.tvStatus.setBackgroundResource(R.drawable.bg_status_dropped)
                    binding.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_dropped))
                }
                StudentStatusType.MISSING -> {
                    binding.tvStatus.text = context.getString(R.string.missing)
                    binding.tvStatus.setBackgroundResource(R.drawable.bg_status_missing)
                    binding.tvStatus.setTextColor(ContextCompat.getColor(context, R.color.status_missing))
                }
            }
        }

        private fun setupActionButtons(item: StudentListItem) {
            val ssid = item.student.studentSessionId

            // Reset visibility
            binding.btnMissing.visibility = View.VISIBLE
            binding.btnBoard.visibility = View.VISIBLE
            binding.btnDrop.visibility = View.GONE

            when (tripMode) {
                TripMode.PICKUP -> {
                    // Pickup mode: Show "Board" and "Missing"
                    binding.btnDrop.visibility = View.GONE
                    
                    when (item.currentStatus) {
                        StudentStatusType.MISSING -> {
                            binding.btnBoard.visibility = View.VISIBLE
                            binding.btnMissing.visibility = View.GONE
                        }
                        StudentStatusType.ON_BUS -> {
                            binding.btnBoard.visibility = View.GONE
                            binding.btnMissing.visibility = View.VISIBLE
                        }
                        StudentStatusType.DROPPED -> {
                            binding.btnBoard.visibility = View.GONE
                            binding.btnMissing.visibility = View.VISIBLE
                        }
                    }
                }
                TripMode.DROP -> {
                    // Drop mode: Show "Drop", "Board" and "Missing"
                    binding.btnDrop.visibility = View.VISIBLE
                    
                    when (item.currentStatus) {
                        StudentStatusType.MISSING -> {
                            binding.btnBoard.visibility = View.VISIBLE
                            binding.btnDrop.visibility = View.GONE
                            binding.btnMissing.visibility = View.GONE
                        }
                        StudentStatusType.ON_BUS -> {
                            binding.btnBoard.visibility = View.GONE
                            binding.btnDrop.visibility = View.VISIBLE
                            binding.btnMissing.visibility = View.VISIBLE
                        }
                        StudentStatusType.DROPPED -> {
                            binding.btnBoard.visibility = View.GONE
                            binding.btnDrop.visibility = View.GONE
                            binding.btnMissing.visibility = View.VISIBLE
                        }
                    }
                }
            }

            // Click listeners
            binding.btnMissing.setOnClickListener {
                onManualStatus(ssid, "missing")
            }

            binding.btnBoard.setOnClickListener {
                onManualStatus(ssid, "board")
            }

            binding.btnDrop.setOnClickListener {
                onManualStatus(ssid, "drop")
            }
        }

        private fun formatTime(datetime: String?): String? {
            if (datetime.isNullOrBlank()) return null
            
            return try {
                val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                val outputFormat = SimpleDateFormat("HH:mm", Locale.US)
                val date = inputFormat.parse(datetime)
                date?.let { outputFormat.format(it) }
            } catch (e: Exception) {
                null
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<StudentListItem>() {
        override fun areItemsTheSame(oldItem: StudentListItem, newItem: StudentListItem): Boolean {
            return oldItem.student.studentSessionId == newItem.student.studentSessionId
        }

        override fun areContentsTheSame(oldItem: StudentListItem, newItem: StudentListItem): Boolean {
            return oldItem == newItem
        }
    }
}
